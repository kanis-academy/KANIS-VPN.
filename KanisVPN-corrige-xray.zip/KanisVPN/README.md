# KANIS VPN — Android project

A VPN client app (Kotlin, single-module Gradle project) built to the brief: the reference
screen's layout and flow, a navy/gold shield-and-keyhole identity, light/dark themes, a
decorative tunnel background, multi-protocol support, clipboard import, an in-app public-IP
panel, and an optional (fully transparent) profile lock.

## What's inside

- **UI**: `SplashActivity` (animated logo, auto-navigates to `MainActivity`), `MainActivity`
  (status, timer, username/remark/host/port fields, protocol picker, Connect, Save/Share/
  Profiles, Import from Clipboard, download/upload counters, public-IP card, footer status
  row), `ProfilesActivity` + `ProfilesAdapter` (saved profile list with lock/unlock/share/
  delete).
- **Model & storage**: `Profile`, `Protocol`, `ProfileRepository` (simple JSON file in
  app-private storage — no server, no account system).
- **Clipboard import**: `ConfigLinkParser` understands `vmess://`, `vless://`, `ss://`,
  `trojan://` links and `wg-quick`-style WireGuard blocks; importing auto-fills the form and
  immediately starts a connection.
- **VPN engines** (`com.kanis.vpn.vpn`):
  - `WireGuardEngine` — wraps the official `com.wireguard.android:tunnel` library. Builds
    and runs with no extra setup.
  - `XrayEngine` — drives Xray-core (VMess, VLESS, Shadowsocks, Trojan) through the
    `AndroidLibXrayLite` binding (JitPack: `com.github.2dust:AndroidLibXrayLite`). See the
    **build notes** below — gomobile bindings occasionally rename their Java-facing package,
    so this is the one piece worth a quick look after your first Gradle sync.
  - `SshTunnelEngine` — stubbed. A plain SSH SOCKS tunnel is easy to add (JSch), but routing
    the *whole device* through it needs a SOCKS→TUN bridge; the class doc explains the two
    ways to finish it.
- **Public IP panel**: `PublicIpFetcher` calls a public IP-echo API once connected.

## Honesty note on the "lock" feature

The profile lock is a genuine, user-controlled "mark as read-only" toggle: the person who
created a profile can lock it (with a timestamp) to stop accidental edits, and unlock it
again just as easily. The host, port and every other field stay fully visible on screen and
in any export at all times — nothing is hidden, obfuscated, or stripped from a shared file.
That was a deliberate line in how this app was built: a client that concealed its own server
address from the people using it would be a billing-bypass / resale tool aimed at an ISP's
zero-rated domain, which is a different (and not something I'll build) kind of "lock."

## Build notes

1. Open the `KanisVPN/` folder in Android Studio (Koala+ recommended). Let Gradle sync —
   it will pull WireGuard and AndroidLibXrayLite from JitPack/Maven on first sync, so your
   machine needs normal internet access for that one-time step.
2. If Android Studio flags the `libXray.CoreCallbackHandler` / `libXray.Libxray` /
   `libXray.CoreController` references in `XrayEngine.kt` (shown in red before the first
   sync completes), open the AAR in the external-libraries panel and check the actual
   top-level package the `main-SNAPSHOT` build published — gomobile occasionally changes
   casing (`libXray` vs `libxray`) between snapshots. Update the three references in that
   one file to match; nothing else depends on the exact name.
3. Build → Make Project, then Run on a device or emulator with Google Play services (for the
   VPN permission dialog) or any API 24+ image.
4. First run will ask for the VPN permission and (Android 13+) notification permission —
   both are needed for the foreground VPN service and its status notification.

## Protocols

| Protocol | Engine | Status |
|---|---|---|
| VMess | Xray-core | Ready |
| VLESS | Xray-core | Ready |
| Shadowsocks | Xray-core | Ready |
| Trojan | Xray-core | Ready |
| WireGuard | wireguard-android | Ready |
| SSH Tunnel | — | Stubbed, see `SshTunnelEngine.kt` |

## Your own server

This is a client. Point it at infrastructure you run or are authorized to use (a VPS with
Xray/V2Ray, WireGuard, or an SSH server) — paste a `vmess://`/`vless://`/`ss://`/`trojan://`
link via **Import from Clipboard**, or fill the fields and press **Save**.
