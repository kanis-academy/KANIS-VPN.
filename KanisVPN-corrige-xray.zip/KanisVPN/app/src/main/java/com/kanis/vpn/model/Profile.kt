package com.kanis.vpn.model

import org.json.JSONObject
import java.util.UUID

/**
 * A connection profile. Nothing in here is ever hidden from the user who owns it:
 * [locked] only flips the UI between editable and read-only (set by the owner, with
 * a timestamp, and reversible by the owner). The host/port/credentials always remain
 * visible and are always exported in full, in plain text.
 */
data class Profile(
    val id: String = UUID.randomUUID().toString(),
    var username: String = "",
    var remark: String = "",
    var host: String = "",
    var port: Int = 443,
    var protocol: Protocol = Protocol.VMESS,
    /** Protocol-specific fields (uuid, password, publicKey, presharedKey, network, path, tls...) */
    var params: MutableMap<String, String> = mutableMapOf(),
    var locked: Boolean = false,
    var lockedAtEpochMs: Long? = null,
    val createdAtEpochMs: Long = System.currentTimeMillis()
) {

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("username", username)
        put("remark", remark)
        put("host", host)
        put("port", port)
        put("protocol", protocol.name)
        put("params", JSONObject(params as Map<*, *>))
        put("locked", locked)
        put("lockedAtEpochMs", lockedAtEpochMs ?: JSONObject.NULL)
        put("createdAtEpochMs", createdAtEpochMs)
    }

    /** Plain-text, human-readable export. Always complete -- never masks the host. */
    fun toExportText(): String {
        val sb = StringBuilder()
        sb.appendLine("# KANIS VPN profile")
        sb.appendLine("remark=$remark")
        sb.appendLine("username=$username")
        sb.appendLine("protocol=${protocol.name}")
        sb.appendLine("host=$host")
        sb.appendLine("port=$port")
        params.forEach { (k, v) -> sb.appendLine("$k=$v") }
        if (locked && lockedAtEpochMs != null) {
            sb.appendLine("# locked_at=$lockedAtEpochMs (read-only copy; host is still shown above)")
        }
        return sb.toString()
    }

    /** Single-line share link, in the scheme matching the protocol when one exists. */
    fun toShareLink(): String = when (protocol) {
        Protocol.VMESS -> {
            val obj = JSONObject().apply {
                put("v", "2")
                put("ps", remark)
                put("add", host)
                put("port", port)
                put("id", params["uuid"] ?: "")
                put("aid", params["alterId"] ?: "0")
                put("net", params["network"] ?: "tcp")
                put("type", params["headerType"] ?: "none")
                put("host", params["requestHost"] ?: "")
                put("path", params["path"] ?: "")
                put("tls", params["tls"] ?: "")
            }
            "vmess://" + android.util.Base64.encodeToString(
                obj.toString().toByteArray(), android.util.Base64.NO_WRAP
            )
        }
        Protocol.VLESS -> {
            val uuid = params["uuid"] ?: ""
            val query = listOfNotNull(
                params["encryption"]?.let { "encryption=$it" } ?: "encryption=none",
                params["security"]?.let { "security=$it" },
                params["type"]?.let { "type=$it" }
            ).joinToString("&")
            "vless://$uuid@$host:$port?$query#${urlEncode(remark)}"
        }
        Protocol.SHADOWSOCKS -> {
            val method = params["method"] ?: "aes-256-gcm"
            val password = params["password"] ?: ""
            val userInfo = android.util.Base64.encodeToString(
                "$method:$password".toByteArray(), android.util.Base64.NO_WRAP
            )
            "ss://$userInfo@$host:$port#${urlEncode(remark)}"
        }
        Protocol.TROJAN -> {
            val password = params["password"] ?: ""
            "trojan://$password@$host:$port#${urlEncode(remark)}"
        }
        Protocol.WIREGUARD -> toExportText() // wg-quick style config is clearer as a full block
        Protocol.SSH_TUNNEL -> toExportText()
    }

    companion object {
        fun fromJson(json: JSONObject): Profile {
            val paramsJson = json.optJSONObject("params") ?: JSONObject()
            val params = mutableMapOf<String, String>()
            paramsJson.keys().forEach { k -> params[k] = paramsJson.getString(k) }
            return Profile(
                id = json.getString("id"),
                username = json.optString("username"),
                remark = json.optString("remark"),
                host = json.optString("host"),
                port = json.optInt("port", 443),
                protocol = Protocol.valueOf(json.optString("protocol", Protocol.VMESS.name)),
                params = params,
                locked = json.optBoolean("locked", false),
                lockedAtEpochMs = if (json.isNull("lockedAtEpochMs")) null else json.optLong("lockedAtEpochMs"),
                createdAtEpochMs = json.optLong("createdAtEpochMs", System.currentTimeMillis())
            )
        }
    }
}

/** Tiny helper so URL fragments are safely encoded. */
private fun urlEncode(value: String): String =
    java.net.URLEncoder.encode(value, "UTF-8")
