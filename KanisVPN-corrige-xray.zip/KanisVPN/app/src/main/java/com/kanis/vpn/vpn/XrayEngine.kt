package com.kanis.vpn.vpn

import android.content.Context
import com.kanis.vpn.model.Profile
import com.kanis.vpn.model.Protocol
import org.json.JSONArray
import org.json.JSONObject

/**
 * Drives Xray-core (VMess, VLESS, Shadowsocks, Trojan all run on the same engine --
 * only the "outbound" block of the config differs) through the AndroidLibXrayLite AAR
 * declared in app/build.gradle.kts (com.github.2dust:AndroidLibXrayLite).
 *
 * IMPORTANT BUILD NOTE
 * The library is a gomobile-generated binding, so the exact Java package/class name
 * (shown below as `libXray.Libxray`) can shift slightly between snapshot builds.
 * Confirmed Go API (pkg.go.dev/github.com/2dust/AndroidLibXrayLite) as of writing:
 *   - Libxray.newCoreController(handler): CoreController
 *   - CoreController.startLoop(configJson: String, tunFd: Int): throws on error
 *   - CoreController.stopLoop()
 *   - CoreController.queryAllOutboundTrafficStats(): String  (comma-separated counters)
 * If Android Studio's autocomplete shows a different class name after the first Gradle
 * sync, update the two `import` lines below to match -- the calls themselves won't change.
 */
class XrayEngine(private val context: Context) : VpnEngine {

    private var controller: Any? = null
    override var isRunning: Boolean = false
        private set

    private var callback: VpnEngineCallback? = null

    fun setCallback(cb: VpnEngineCallback) {
        callback = cb
    }

    override fun start(profile: Profile, tunFd: Int) {
        try {
            val configJson = buildConfig(profile).toString()
            val handler = object : libv2ray.CoreCallbackHandler {
                override fun startup(): Int {
                    isRunning = true
                    callback?.onConnected()
                    return 0
                }

                override fun shutdown(): Int {
                    isRunning = false
                    callback?.onDisconnected(null)
                    return 0
                }

                override fun onEmitStatus(code: Int, message: String): Int {
                    if (code != 0L) callback?.onError(message ?: "Xray error ($code)")
                    return 0
                }
            }
            val coreController = libv2ray.NewCoreController(handler)
            controller = coreController
            coreController.startLoop(configJson, tunFd.toLong())
        } catch (e: Exception) {
            callback?.onError("Xray start failed: ${e.message}")
        }
    }

    override fun stop() {
        try {
            (controller as? libv2ray.CoreController)?.stopLoop()
        } catch (e: Exception) {
            // already stopped
        } finally {
            isRunning = false
        }
    }

    override fun currentStats(): TrafficStats {
        return try {
            val raw = (controller as? libv2ray.CoreController)?.queryAllOutboundTrafficStats() ?: return TrafficStats(0, 0)
            // Documented as a comma-separated set of counters; exact ordering can vary by
            // build, so this picks out the first two numeric tokens defensively.
            val numbers = Regex("\\d+").findAll(raw).map { it.value.toLongOrNull() ?: 0L }.toList()
            TrafficStats(numbers.getOrElse(0) { 0L }, numbers.getOrElse(1) { 0L })
        } catch (e: Exception) {
            TrafficStats(0, 0)
        }
    }

    /** Builds a minimal Xray JSON config: one TUN-fed inbound, one outbound matching the profile's protocol. */
    private fun buildConfig(profile: Profile): JSONObject {
        val root = JSONObject()
        root.put("log", JSONObject().put("loglevel", "warning"))

        // Inbound: Xray reads/writes directly on the fd VpnService handed us.
        val inbound = JSONObject().apply {
            put("tag", "tun-in")
            put("protocol", "dokodemo-door")
            put("settings", JSONObject().put("network", "tcp,udp"))
        }
        root.put("inbounds", JSONArray().put(inbound))

        val outbound = JSONObject().apply {
            put("tag", "proxy")
            when (profile.protocol) {
                Protocol.VMESS -> {
                    put("protocol", "vmess")
                    put("settings", JSONObject().put("vnext", JSONArray().put(
                        JSONObject().apply {
                            put("address", profile.host)
                            put("port", profile.port)
                            put("users", JSONArray().put(JSONObject().apply {
                                put("id", profile.params["uuid"])
                                put("alterId", (profile.params["alterId"] ?: "0").toIntOrNull() ?: 0)
                                put("security", "auto")
                            }))
                        }
                    )))
                    put("streamSettings", streamSettings(profile))
                }
                Protocol.VLESS -> {
                    put("protocol", "vless")
                    put("settings", JSONObject().put("vnext", JSONArray().put(
                        JSONObject().apply {
                            put("address", profile.host)
                            put("port", profile.port)
                            put("users", JSONArray().put(JSONObject().apply {
                                put("id", profile.params["uuid"])
                                put("encryption", profile.params["encryption"] ?: "none")
                            }))
                        }
                    )))
                    put("streamSettings", streamSettings(profile))
                }
                Protocol.SHADOWSOCKS -> {
                    put("protocol", "shadowsocks")
                    put("settings", JSONObject().put("servers", JSONArray().put(
                        JSONObject().apply {
                            put("address", profile.host)
                            put("port", profile.port)
                            put("method", profile.params["method"] ?: "aes-256-gcm")
                            put("password", profile.params["password"] ?: "")
                        }
                    )))
                }
                Protocol.TROJAN -> {
                    put("protocol", "trojan")
                    put("settings", JSONObject().put("servers", JSONArray().put(
                        JSONObject().apply {
                            put("address", profile.host)
                            put("port", profile.port)
                            put("password", profile.params["password"] ?: "")
                        }
                    )))
                    put("streamSettings", streamSettings(profile))
                }
                else -> throw IllegalArgumentException("XrayEngine cannot handle ${profile.protocol}")
            }
        }
        root.put("outbounds", JSONArray().put(outbound).put(JSONObject().put("protocol", "freedom").put("tag", "direct")))
        return root
    }

    private fun streamSettings(profile: Profile): JSONObject {
        val network = profile.params["network"] ?: "tcp"
        val tls = profile.params["tls"]
        val settings = JSONObject().put("network", network)
        if (network == "ws") {
            settings.put("wsSettings", JSONObject().apply {
                put("path", profile.params["path"] ?: "/")
                profile.params["requestHost"]?.takeIf { it.isNotBlank() }?.let {
                    put("headers", JSONObject().put("Host", it))
                }
            })
        }
        if (!tls.isNullOrBlank() && tls != "none") {
            settings.put("security", "tls")
            settings.put("tlsSettings", JSONObject().put("serverName", profile.params["requestHost"] ?: profile.host))
        }
        return settings
    }
}
