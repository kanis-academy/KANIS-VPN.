package com.kanis.vpn.model

/**
 * Every tunneling protocol KANIS VPN can speak. Adding a new one means:
 *  1. a new entry here,
 *  2. a branch in [com.kanis.vpn.vpn.VpnEngineFactory],
 *  3. (optionally) a parser case in [com.kanis.vpn.util.ConfigLinkParser].
 */
enum class Protocol(val displayName: String, val uriScheme: String?) {
    VMESS("VMess (V2Ray)", "vmess"),
    VLESS("VLESS (Xray)", "vless"),
    SHADOWSOCKS("Shadowsocks", "ss"),
    TROJAN("Trojan", "trojan"),
    WIREGUARD("WireGuard", null),
    SSH_TUNNEL("SSH Tunnel", null);

    companion object {
        fun fromUriScheme(scheme: String): Protocol? =
            entries.firstOrNull { it.uriScheme.equals(scheme, ignoreCase = true) }

        fun fromDisplayName(name: String): Protocol =
            entries.firstOrNull { it.displayName == name } ?: VMESS
    }
}
