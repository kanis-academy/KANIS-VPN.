package com.kanis.vpn.util

import android.util.Base64
import com.kanis.vpn.model.Profile
import com.kanis.vpn.model.Protocol
import org.json.JSONObject

/**
 * Turns a pasted subscription link (vmess://, vless://, ss://, trojan://, or a wg-quick
 * [Interface]/[Peer] block) into a [Profile]. Used by "Import from clipboard".
 */
object ConfigLinkParser {

    fun parse(raw: String): Profile? {
        val text = raw.trim()
        if (text.isEmpty()) return null
        return try {
            when {
                text.startsWith("vmess://", true) -> parseVmess(text)
                text.startsWith("vless://", true) -> parseVless(text)
                text.startsWith("ss://", true) -> parseShadowsocks(text)
                text.startsWith("trojan://", true) -> parseTrojan(text)
                text.contains("[Interface]") && text.contains("[Peer]") -> parseWireGuard(text)
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseVmess(text: String): Profile {
        val payload = text.removePrefix("vmess://")
        val decoded = String(Base64.decode(payload, Base64.DEFAULT))
        val json = JSONObject(decoded)
        return Profile(
            username = "imported",
            remark = json.optString("ps", "Imported VMess"),
            host = json.optString("add"),
            port = json.optString("port", "443").toIntOrNull() ?: 443,
            protocol = Protocol.VMESS,
            params = mutableMapOf(
                "uuid" to json.optString("id"),
                "alterId" to json.optString("aid", "0"),
                "network" to json.optString("net", "tcp"),
                "headerType" to json.optString("type", "none"),
                "requestHost" to json.optString("host", ""),
                "path" to json.optString("path", ""),
                "tls" to json.optString("tls", "")
            )
        )
    }

    private fun parseVless(text: String): Profile {
        val withoutScheme = text.removePrefix("vless://")
        val fragmentSplit = withoutScheme.split("#")
        val remark = fragmentSplit.getOrNull(1)?.let { java.net.URLDecoder.decode(it, "UTF-8") } ?: "Imported VLESS"
        val main = fragmentSplit[0]
        val atSplit = main.split("@")
        val uuid = atSplit[0]
        val rest = atSplit.getOrElse(1) { "" }
        val hostPortAndQuery = rest.split("?")
        val hostPort = hostPortAndQuery[0]
        val query = hostPortAndQuery.getOrElse(1) { "" }
        val host = hostPort.substringBeforeLast(":")
        val port = hostPort.substringAfterLast(":").toIntOrNull() ?: 443
        val params = parseQuery(query)
        return Profile(
            username = "imported",
            remark = remark,
            host = host,
            port = port,
            protocol = Protocol.VLESS,
            params = (params + ("uuid" to uuid)).toMutableMap()
        )
    }

    private fun parseShadowsocks(text: String): Profile {
        val withoutScheme = text.removePrefix("ss://")
        val fragmentSplit = withoutScheme.split("#")
        val remark = fragmentSplit.getOrNull(1)?.let { java.net.URLDecoder.decode(it, "UTF-8") } ?: "Imported Shadowsocks"
        val main = fragmentSplit[0]
        val atSplit = main.split("@")
        val methodPassword = String(Base64.decode(atSplit[0], Base64.DEFAULT))
        val hostPort = atSplit.getOrElse(1) { "" }
        val host = hostPort.substringBeforeLast(":")
        val port = hostPort.substringAfterLast(":").toIntOrNull() ?: 8388
        val method = methodPassword.substringBefore(":")
        val password = methodPassword.substringAfter(":")
        return Profile(
            username = "imported",
            remark = remark,
            host = host,
            port = port,
            protocol = Protocol.SHADOWSOCKS,
            params = mutableMapOf("method" to method, "password" to password)
        )
    }

    private fun parseTrojan(text: String): Profile {
        val withoutScheme = text.removePrefix("trojan://")
        val fragmentSplit = withoutScheme.split("#")
        val remark = fragmentSplit.getOrNull(1)?.let { java.net.URLDecoder.decode(it, "UTF-8") } ?: "Imported Trojan"
        val main = fragmentSplit[0]
        val atSplit = main.split("@")
        val password = atSplit[0]
        val hostPort = atSplit.getOrElse(1) { "" }
        val host = hostPort.substringBeforeLast(":")
        val port = hostPort.substringAfterLast(":").toIntOrNull() ?: 443
        return Profile(
            username = "imported",
            remark = remark,
            host = host,
            port = port,
            protocol = Protocol.TROJAN,
            params = mutableMapOf("password" to password)
        )
    }

    private fun parseWireGuard(text: String): Profile {
        val lines = text.lines().map { it.trim() }
        fun value(key: String): String =
            lines.firstOrNull { it.startsWith("$key =", true) || it.startsWith("$key=", true) }
                ?.substringAfter("=")?.trim() ?: ""

        val endpoint = value("Endpoint")
        val host = endpoint.substringBeforeLast(":")
        val port = endpoint.substringAfterLast(":").toIntOrNull() ?: 51820
        return Profile(
            username = "imported",
            remark = "Imported WireGuard",
            host = host,
            port = port,
            protocol = Protocol.WIREGUARD,
            params = mutableMapOf(
                "privateKey" to value("PrivateKey"),
                "address" to value("Address"),
                "dns" to value("DNS"),
                "publicKey" to value("PublicKey"),
                "presharedKey" to value("PresharedKey"),
                "allowedIPs" to value("AllowedIPs")
            )
        )
    }

    private fun parseQuery(query: String): Map<String, String> =
        query.split("&").filter { it.contains("=") }.associate {
            val (k, v) = it.split("=", limit = 2)
            java.net.URLDecoder.decode(k, "UTF-8") to java.net.URLDecoder.decode(v, "UTF-8")
        }
}
