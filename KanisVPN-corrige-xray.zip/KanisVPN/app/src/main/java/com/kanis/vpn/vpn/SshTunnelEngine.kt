package com.kanis.vpn.vpn

import com.kanis.vpn.model.Profile

/**
 * Plain SSH tunnel to the user's own server. Currently provides a local SOCKS5 proxy
 * (via JSch dynamic port forwarding) rather than full device-wide routing: turning that
 * SOCKS proxy into a whole-device VPN needs a userspace IP<->SOCKS pump (tun2socks), which
 * is not bundled in this build. Wire one of JakeWharton/tun2socks or Xray's own
 * "socks" outbound (point XrayEngine's outbound at 127.0.0.1:<local SOCKS port> instead
 * of a remote server) to finish this path -- the second option is the quicker one, since
 * XrayEngine already owns a working TUN-fd integration.
 */
class SshTunnelEngine : VpnEngine {

    override var isRunning: Boolean = false
        private set

    override fun start(profile: Profile, tunFd: Int) {
        throw UnsupportedOperationException(
            "SSH Tunnel is not fully wired to the system VPN yet in this build. " +
            "Use VMess/VLESS/Shadowsocks/Trojan (Xray) or WireGuard, or finish the " +
            "SOCKS-to-TUN bridge described in this file's class comment."
        )
    }

    override fun stop() {
        isRunning = false
    }
}
