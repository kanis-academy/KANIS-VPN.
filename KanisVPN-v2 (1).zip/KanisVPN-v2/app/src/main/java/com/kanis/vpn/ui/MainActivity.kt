package com.kanis.vpn.ui

import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.kanis.vpn.R
import com.kanis.vpn.databinding.ActivityMainBinding
import com.kanis.vpn.model.Profile
import com.kanis.vpn.model.Protocol
import com.kanis.vpn.profile.ProfileRepository
import com.kanis.vpn.util.ConfigLinkParser
import com.kanis.vpn.util.PublicIpFetcher
import com.kanis.vpn.vpn.KanisVpnService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repo: ProfileRepository

    private var currentProfile = Profile()
    private var connected = false
    private var connectingStartMs = 0L
    private val timerHandler = Handler(Looper.getMainLooper())
    private var timerRunnable: Runnable? = null
    private val uiScope = CoroutineScope(Dispatchers.Main + Job())

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) startVpnService() else Toast.makeText(
            this, getString(R.string.permission_vpn_rationale), Toast.LENGTH_LONG
        ).show()
    }

    private val profilesLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val id = result.data?.getStringExtra("profile_id") ?: return@registerForActivityResult
        repo.loadAll().firstOrNull { it.id == id }?.let {
            currentProfile = it
            bindProfileToFields(it)
        }
    }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op either way, foreground service still runs */ }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != KanisVpnService.ACTION_STATUS) return
            when (intent.getStringExtra(KanisVpnService.EXTRA_STATUS)) {
                KanisVpnService.STATUS_CONNECTING -> setConnectingUi()
                KanisVpnService.STATUS_CONNECTED -> {
                    setConnectedUi()
                    val rx = intent.getLongExtra(KanisVpnService.EXTRA_RX, 0)
                    val tx = intent.getLongExtra(KanisVpnService.EXTRA_TX, 0)
                    binding.txtDownload.text = formatSpeed(rx)
                    binding.txtUpload.text = formatSpeed(tx)
                }
                KanisVpnService.STATUS_DISCONNECTED -> setDisconnectedUi()
                KanisVpnService.STATUS_ERROR -> {
                    setDisconnectedUi()
                    val msg = intent.getStringExtra("message")
                    Toast.makeText(this@MainActivity, msg ?: "Connection error", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = ProfileRepository(this)
        currentProfile = repo.loadAll().lastOrNull() ?: Profile()

        setupProtocolSpinner()
        bindProfileToFields(currentProfile)
        setDisconnectedUi()

        binding.btnConnect.setOnClickListener { onConnectClicked() }
        binding.btnSave.setOnClickListener { onSaveClicked() }
        binding.btnShare.setOnClickListener { onShareClicked() }
        binding.btnProfiles.setOnClickListener {
            profilesLauncher.launch(Intent(this, ProfilesActivity::class.java))
        }
        binding.btnParams.setOnClickListener {
            ParamsDialog.show(this, collectProfileFromFields()) { updated -> currentProfile = updated }
        }
        binding.btnImportClipboard.setOnClickListener { onImportClipboardClicked() }
        binding.imgLockBadge.setOnClickListener { onToggleLockClicked() }

        requestNotificationPermissionIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(KanisVpnService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(statusReceiver) } catch (e: Exception) { /* not registered */ }
    }

    // ---------- Protocol spinner ----------

    private fun setupProtocolSpinner() {
        val names = Protocol.entries.map { it.displayName }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerProtocol.adapter = adapter
        binding.spinnerProtocol.setSelection(names.indexOf(currentProfile.protocol.displayName))
    }

    // ---------- Field <-> Profile binding ----------

    private fun bindProfileToFields(profile: Profile) {
        binding.edtUsername.setText(profile.username)
        binding.edtRemark.setText(profile.remark)
        binding.edtHost.setText(profile.host)
        binding.edtPort.setText(profile.port.toString())
        val index = Protocol.entries.indexOf(profile.protocol)
        if (index >= 0) binding.spinnerProtocol.setSelection(index)
        applyLockUi(profile.locked)
    }

    private fun collectProfileFromFields(): Profile {
        val protocolName = binding.spinnerProtocol.selectedItem?.toString() ?: Protocol.VMESS.displayName
        val newProtocol = Protocol.fromDisplayName(protocolName)
        val keepParams = newProtocol == currentProfile.protocol
        return currentProfile.copy(
            params = if (keepParams) currentProfile.params else mutableMapOf(),
            username = binding.edtUsername.text.toString(),
            remark = binding.edtRemark.text.toString(),
            host = binding.edtHost.text.toString(),
            port = binding.edtPort.text.toString().toIntOrNull() ?: 443,
            protocol = Protocol.fromDisplayName(protocolName)
        )
    }

    private fun applyLockUi(locked: Boolean) {
        binding.imgLockBadge.visibility = if (locked) android.view.View.VISIBLE else android.view.View.GONE
        binding.imgLockBadge.setImageResource(if (locked) R.drawable.ic_lock else R.drawable.ic_unlock)
        val editable = !locked
        binding.edtUsername.isEnabled = editable
        binding.edtRemark.isEnabled = editable
        binding.edtHost.isEnabled = editable
        binding.edtPort.isEnabled = editable
        binding.spinnerProtocol.isEnabled = editable
        binding.btnParams.isEnabled = editable
    }

    // ---------- Button actions ----------

    private fun onConnectClicked() {
        if (connected) {
            stopVpnService()
            return
        }
        currentProfile = collectProfileFromFields()
        if (currentProfile.host.isBlank()) {
            Toast.makeText(this, "Enter a host first", Toast.LENGTH_SHORT).show()
            return
        }
        val vpnIntent = VpnService.prepare(this)
        if (vpnIntent != null) {
            vpnPermissionLauncher.launch(vpnIntent)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        setConnectingUi()
        val intent = Intent(this, KanisVpnService::class.java).apply {
            action = KanisVpnService.ACTION_CONNECT
            putExtra(KanisVpnService.EXTRA_PROFILE_JSON, currentProfile.toJson().toString())
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopVpnService() {
        val intent = Intent(this, KanisVpnService::class.java).apply {
            action = KanisVpnService.ACTION_DISCONNECT
        }
        startService(intent)
    }

    private fun onSaveClicked() {
        val profile = collectProfileFromFields()
        if (profile.host.isBlank()) {
            Toast.makeText(this, "Enter a host first", Toast.LENGTH_SHORT).show()
            return
        }
        currentProfile = profile
        repo.upsert(profile)
        Toast.makeText(this, R.string.toast_saved, Toast.LENGTH_SHORT).show()
    }

    private fun onShareClicked() {
        val profile = collectProfileFromFields()
        if (profile.host.isBlank()) {
            Toast.makeText(this, "Enter a host first", Toast.LENGTH_SHORT).show()
            return
        }
        // Plain-text export: host, port and every field stay fully visible and editable
        // by whoever receives it. No field is masked or hidden here.
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "KANIS VPN profile: ${profile.remark}")
            putExtra(Intent.EXTRA_TEXT, profile.toExportText())
        }
        startActivity(Intent.createChooser(shareIntent, getString(R.string.btn_share)))
        Toast.makeText(this, R.string.toast_exported, Toast.LENGTH_SHORT).show()
    }

    private fun onToggleLockClicked() {
        val locked = !currentProfile.locked
        currentProfile.locked = locked
        currentProfile.lockedAtEpochMs = if (locked) System.currentTimeMillis() else null
        if (repo.loadAll().any { it.id == currentProfile.id }) {
            repo.setLocked(currentProfile.id, locked)
        }
        applyLockUi(locked)
        val msg = if (locked) {
            val time = java.text.SimpleDateFormat("HH:mm, dd MMM", Locale.getDefault())
                .format(java.util.Date(currentProfile.lockedAtEpochMs ?: System.currentTimeMillis()))
            getString(R.string.toast_locked, time)
        } else {
            getString(R.string.toast_unlocked)
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun onImportClipboardClicked() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip
        if (clip == null || clip.itemCount == 0) {
            Toast.makeText(this, R.string.toast_clipboard_empty, Toast.LENGTH_SHORT).show()
            return
        }
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val all = ConfigLinkParser.parseAll(text)
        val parsed = all.firstOrNull()
        if (parsed == null) {
            Toast.makeText(this, R.string.toast_clipboard_invalid, Toast.LENGTH_SHORT).show()
            return
        }
        if (all.size > 1) { // subscription: keep every profile in the list
            all.forEach { repo.upsert(it) }
            Toast.makeText(this, getString(R.string.toast_imported_many, all.size), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, R.string.toast_imported, Toast.LENGTH_SHORT).show()
        }
        currentProfile = parsed
        bindProfileToFields(parsed)
        // "copy -> import -> connect" as requested: launch the connection right away.
        onConnectClicked()
    }

    // ---------- Status UI ----------

    private fun setConnectingUi() {
        connected = false
        binding.txtStatus.text = getString(R.string.status_connecting)
        binding.txtStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_gold_500))
        binding.btnConnect.text = getString(R.string.status_connecting)
        binding.progressWheel.visibility = android.view.View.VISIBLE
        binding.txtFooterStatus.text = getString(R.string.status_connecting)
        binding.imgUpdateDot.visibility = android.view.View.INVISIBLE
    }

    private fun setConnectedUi() {
        connected = true
        binding.txtStatus.text = getString(R.string.status_connected)
        binding.txtStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_green))
        binding.btnConnect.text = getString(R.string.btn_disconnect)
        binding.progressWheel.visibility = android.view.View.INVISIBLE
        binding.txtFooterStatus.text = getString(R.string.status_connected)
        binding.txtFooterStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_green))
        binding.imgUpdateDot.visibility = android.view.View.VISIBLE
        startTimer()
        fetchPublicIp()
    }

    private fun setDisconnectedUi() {
        connected = false
        binding.txtStatus.text = getString(R.string.status_disconnected)
        binding.txtStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_red))
        binding.btnConnect.text = getString(R.string.btn_connect)
        binding.progressWheel.visibility = android.view.View.INVISIBLE
        binding.txtFooterStatus.text = getString(R.string.status_check_credentials)
        binding.txtFooterStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_red))
        binding.imgUpdateDot.visibility = android.view.View.INVISIBLE
        binding.txtDownload.text = "0 kb/s"
        binding.txtUpload.text = "0 kb/s"
        binding.txtIpValue.text = getString(R.string.label_not_connected)
        stopTimer()
    }

    // ---------- Session timer ----------

    private fun startTimer() {
        connectingStartMs = System.currentTimeMillis()
        stopTimer()
        val runnable = object : Runnable {
            override fun run() {
                val elapsed = (System.currentTimeMillis() - connectingStartMs) / 1000
                val h = elapsed / 3600
                val m = (elapsed % 3600) / 60
                val s = elapsed % 60
                binding.txtTimer.text = String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
                timerHandler.postDelayed(this, 1000)
            }
        }
        timerRunnable = runnable
        timerHandler.post(runnable)
    }

    private fun stopTimer() {
        timerRunnable?.let { timerHandler.removeCallbacks(it) }
        timerRunnable = null
        binding.txtTimer.text = "00:00:00"
    }

    // ---------- Public IP panel ----------

    private fun fetchPublicIp() {
        uiScope.launch {
            binding.txtIpValue.text = "…"
            val ip = withContext(Dispatchers.IO) { PublicIpFetcher.fetch() }
            binding.txtIpValue.text = ip ?: getString(R.string.label_not_connected)
        }
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        val kb = bytesPerSec / 1024.0
        return if (kb < 1024) String.format(Locale.US, "%.1f kb/s", kb)
        else String.format(Locale.US, "%.2f MB/s", kb / 1024.0)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
