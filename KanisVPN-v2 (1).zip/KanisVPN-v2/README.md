# KANIS VPN — Android project

A VPN client app (Kotlin, single-module Gradle project) built to the brief: the reference
screen's layout and flow, a navy/gold shield-and-keyhole identity, light/dark themes, a
decorative tunnel background, multi-protocol support, clipboard import, an in-app public-IP
panel, and an optional (fully transparent) profile lock.

## Protocols

| Protocol | Engine | Link import |
|---|---|---|
| VMess (WS / gRPC / HTTP / HTTPUpgrade, TLS) | sing-box | `vmess://` |
| VLESS (TLS, **Reality**, flow vision, gRPC…) | sing-box | `vless://` |
| Trojan | sing-box | `trojan://` |
| Shadowsocks (incl. 2022, plugins) | sing-box | `ss://` (SIP002 + legacy) |
| Hysteria2 | sing-box | `hysteria2://`, `hy2://` |
| TUIC v5 | sing-box | `tuic://` |
| SSH tunnel (password or private key) | sing-box | `ssh://` |
| WireGuard | wireguard-android | wg-quick block |

Import from clipboard also accepts a whole subscription (several links, or base64 of them).
The **PROTOCOL SETTINGS** button edits every field (UUID, password, SNI, Reality keys, transport…).

## Build

1. Push the project to GitHub and run the **Build KanisVPN APK** workflow (Actions tab). It builds
   `libbox.aar` from sing-box `v1.10.7`, then the APKs (one per CPU + universal) and uploads them.
2. Locally: put a `libbox.aar` in `app/libs/` and run `gradle assembleDebug` (Gradle 8.7, JDK 17).

If Gradle reports a `PlatformInterface` mismatch, change only `vpn/SingBoxEngine.kt`
(the libbox API shifts a little between sing-box releases).

## Architecture

- `vpn/SingBoxConfig.kt` builds the sing-box JSON (TUN inbound, proxy outbound, DNS over tunnel).
- `vpn/SingBoxEngine.kt` runs the core and opens the TUN; the app is excluded from its own VPN so
  there is no routing loop.
- `vpn/WireGuardEngine.kt` uses the official backend.
- `vpn/KanisVpnService.kt` validates the profile, runs the engine, shows the notification, reports speed.

## Honesty note on the "lock" feature

The profile lock is a user-controlled "mark as read-only" toggle. Host, port and every field stay
visible on screen and in any export at all times; nothing is hidden or stripped from a shared file.

## Your own server

This is a client. Point it at infrastructure you run or are authorized to use.
