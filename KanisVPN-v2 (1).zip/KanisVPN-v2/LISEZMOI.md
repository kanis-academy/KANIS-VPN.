# Compiler KanisVPN sur GitHub

1. Crée un dépôt vide sur GitHub (ex. `KanisVPN`).
2. Dans ce dossier :

```bash
git init
git add .
git commit -m "KanisVPN"
git branch -M main
git remote add origin https://github.com/TON_PSEUDO/KanisVPN.git
git push -u origin main
```

3. Onglet **Actions → Build KanisVPN APK** : la compilation démarre toute seule (10 à 15 min).
4. Télécharge l'artefact **KanisVPN-apk** (APK par processeur + universel).

Utilise `git push` (pas le glisser-déposer du site) pour que le dossier caché `.github` soit envoyé.
Si une étape est en rouge, envoie-moi les 30 dernières lignes de son journal.
