# KANIS VPN — Android project

A VPN client app (Kotlin, single-module Gradle project) built to the brief: the reference
screen's layout and flow, a navy/gold shield-and-keyhole identity, light/dark themes, a
decorative tunnel background, multi-protocol support, clipboard import, an in-app public-IP
panel, and an optional (fully transparent) profile lock.

## Protocols

| Protocol | Engine | Link import |
|---|---|---|
| VMess (WS / gRPC / HTTP / HTTPUpgrade, TLS) | sing-box | `vmess://` |
| VLESS (TLS, **Reality**, flow vision, gRPC…) | sing-box | `vless://` |
| Trojan | sing-box | `trojan://` |
| Shadowsocks (incl. 2022, plugins) | sing-box | `ss://` (SIP002 + legacy) |
| Hysteria2 | sing-box | `hysteria2://`, `hy2://` |
| TUIC v5 | sing-box | `tuic://` |
| SSH tunnel (password or private key) | sing-box | `ssh://` |
| WireGuard | wireguard-android | wg-quick block |

Import from clipboard also accepts a whole subscription (several links, or base64 of them).
The **PROTOCOL SETTINGS** button edits every field (UUID, password, SNI, Reality keys, transport…).

## Build

1. Push the project to GitHub and run the **Build KanisVPN APK** workflow (Actions tab). It builds
   `libbox.aar` from sing-box `v1.10.7`, then the APKs (one per CPU + universal) and uploads them.
2. Locally: put a `libbox.aar` in `app/libs/` and run `gradle assembleDebug` (Gradle 8.7, JDK 17).

If Gradle reports a `PlatformInterface` mismatch, change only `vpn/SingBoxEngine.kt`
(the libbox API shifts a little between sing-box releases).

## Architecture

- `vpn/SingBoxConfig.kt` builds the sing-box JSON (TUN inbound, proxy outbound, DNS over tunnel).
- `vpn/SingBoxEngine.kt` runs the core and opens the TUN; the app is excluded from its own VPN so
  there is no routing loop.
- `vpn/WireGuardEngine.kt` uses the official backend.
- `vpn/KanisVpnService.kt` validates the profile, runs the engine, shows the notification, reports speed.

## Screens

- **Splash**: logo and name, then the home screen.
- **Home**: top bar with the menu (three bars), the logo and name, and the profile icon. Status, timer, CONNECT, the current profile, public IP and speeds. The app ID and version sit at the bottom.
- **Side menu**: Home, Profile, All profiles, a dark theme switch (light is the default), app ID and version.
- **Profile** (profile icon): username, remark, host, port, protocol, PROTOCOL SETTINGS, an optional expiry date, "block re-sharing", then SAVE / LOCK / EXPORT and IMPORT FROM CLIPBOARD.

## Lock, export, expiry

- **LOCK is permanent.** A locked profile is read-only and nothing in the app can unlock or edit it, for anyone, including its owner. It can only be deleted from the phone.
- **EXPORT locks automatically** before sharing. The exported text carries `locked=1`, the optional `expires=` date and `no_reshare=1`; a phone that imports it keeps the profile locked.
- **Expiry**: after the chosen day the app refuses to connect with that profile (it uses the phone clock).
- **Block re-sharing**: the phone that imports the file cannot export it again.
- Host and port always stay visible, on screen and in the exported text. These rules are enforced by this app only: they do not stop someone from editing the text file or using another VPN client. For a hard cut-off, expire the account on your server.

## Your own server

This is a client. Point it at infrastructure you run or are authorized to use.
