Put libbox.aar here (built by the GitHub workflow, or build it yourself).
