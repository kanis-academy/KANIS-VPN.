package com.kanis.vpn.vpn

import com.kanis.vpn.model.Profile
import com.kanis.vpn.model.Protocol
import org.json.JSONArray
import org.json.JSONObject

/**
 * Builds the sing-box JSON config (1.10 format) for a profile: TUN inbound, one proxy outbound
 * matching the protocol, DNS over the tunnel and DNS hijacking. Only this file knows the
 * sing-box schema; protocol fields come from [Profile.params].
 */
object SingBoxConfig {

    const val TUN_ADDRESS = "172.19.0.1"
    const val TUN_PREFIX = 30
    const val TUN_DNS = "172.19.0.2"
    const val TUN_MTU = 9000

    fun build(profile: Profile): String {
        val root = JSONObject()
        root.put("log", JSONObject().put("level", "warn").put("timestamp", true))

        root.put("dns", JSONObject().apply {
            put("servers", JSONArray()
                .put(JSONObject().put("tag", "remote").put("address", "https://1.1.1.1/dns-query").put("detour", "proxy"))
                .put(JSONObject().put("tag", "local").put("address", "local").put("detour", "direct")))
            // The proxy server's own hostname must be resolved outside the tunnel.
            put("rules", JSONArray().put(JSONObject().put("outbound", "any").put("server", "local")))
            put("strategy", "prefer_ipv4")
        })

        root.put("inbounds", JSONArray().put(JSONObject().apply {
            put("type", "tun")
            put("tag", "tun-in")
            put("inet4_address", "$TUN_ADDRESS/$TUN_PREFIX")
            put("mtu", TUN_MTU)
            put("auto_route", true)
            put("stack", "system")
            put("sniff", true)
        }))

        root.put("outbounds", JSONArray()
            .put(proxyOutbound(profile))
            .put(JSONObject().put("type", "direct").put("tag", "direct"))
            .put(JSONObject().put("type", "dns").put("tag", "dns-out")))

        root.put("route", JSONObject().apply {
            // Our own sockets bypass the TUN through addDisallowedApplication(), so no
            // platform interface monitor is needed.
            put("auto_detect_interface", false)
            put("final", "proxy")
            put("rules", JSONArray()
                .put(JSONObject().put("protocol", "dns").put("outbound", "dns-out"))
                .put(JSONObject().put("ip_is_private", true).put("outbound", "direct")))
        })
        return root.toString()
    }

    private fun proxyOutbound(profile: Profile): JSONObject {
        val p = profile.params
        val o = JSONObject()
        o.put("tag", "proxy")
        o.put("server", profile.host)
        o.put("server_port", profile.port)
        when (profile.protocol) {
            Protocol.VMESS -> {
                o.put("type", "vmess")
                o.put("uuid", p["uuid"] ?: "")
                o.put("security", "auto")
                o.put("alter_id", (p["alterId"] ?: "0").toIntOrNull() ?: 0)
                tls(profile, defaultOn = false)?.let { o.put("tls", it) }
                transport(p)?.let { o.put("transport", it) }
            }
            Protocol.VLESS -> {
                o.put("type", "vless")
                o.put("uuid", p["uuid"] ?: "")
                p["flow"]?.takeIf { it.isNotBlank() }?.let { o.put("flow", it) }
                tls(profile, defaultOn = false)?.let { o.put("tls", it) }
                transport(p)?.let { o.put("transport", it) }
            }
            Protocol.TROJAN -> {
                o.put("type", "trojan")
                o.put("password", p["password"] ?: "")
                tls(profile, defaultOn = true)?.let { o.put("tls", it) }
                transport(p)?.let { o.put("transport", it) }
            }
            Protocol.SHADOWSOCKS -> {
                o.put("type", "shadowsocks")
                o.put("method", p["method"] ?: "aes-256-gcm")
                o.put("password", p["password"] ?: "")
                p["plugin"]?.takeIf { it.isNotBlank() }?.let {
                    o.put("plugin", if (it == "simple-obfs") "obfs-local" else it)
                    o.put("plugin_opts", p["pluginOpts"] ?: "")
                }
            }
            Protocol.HYSTERIA2 -> {
                o.put("type", "hysteria2")
                o.put("password", p["password"] ?: "")
                p["upMbps"]?.toIntOrNull()?.let { o.put("up_mbps", it) }
                p["downMbps"]?.toIntOrNull()?.let { o.put("down_mbps", it) }
                p["obfs"]?.takeIf { it.isNotBlank() }?.let {
                    o.put("obfs", JSONObject().put("type", it).put("password", p["obfsPassword"] ?: ""))
                }
                o.put("tls", tls(profile, defaultOn = true, forceTls = true)!!)
            }
            Protocol.TUIC -> {
                o.put("type", "tuic")
                o.put("uuid", p["uuid"] ?: "")
                o.put("password", p["password"] ?: "")
                o.put("congestion_control", p["congestion"]?.takeIf { it.isNotBlank() } ?: "bbr")
                o.put("udp_relay_mode", p["udpRelayMode"]?.takeIf { it.isNotBlank() } ?: "native")
                o.put("tls", tls(profile, defaultOn = true, forceTls = true)!!)
            }
            Protocol.SSH_TUNNEL -> {
                o.put("type", "ssh")
                o.put("user", profile.username.ifBlank { "root" })
                p["password"]?.takeIf { it.isNotBlank() }?.let { o.put("password", it) }
                p["privateKey"]?.takeIf { it.isNotBlank() }?.let { o.put("private_key", it) }
            }
            Protocol.WIREGUARD -> throw IllegalArgumentException("WireGuard runs on its own backend")
        }
        return o
    }

    /** TLS / Reality block. Returns null when the outbound is plain. */
    private fun tls(profile: Profile, defaultOn: Boolean, forceTls: Boolean = false): JSONObject? {
        val p = profile.params
        val security = p["security"]?.takeIf { it.isNotBlank() } ?: when {
            p["tls"] == "tls" -> "tls" // profiles saved by the previous version
            defaultOn || forceTls -> "tls"
            else -> "none"
        }
        if (security == "none" && !forceTls) return null
        val t = JSONObject().put("enabled", true)
        t.put("server_name", p["sni"]?.takeIf { it.isNotBlank() } ?: p["requestHost"]?.takeIf { it.isNotBlank() } ?: profile.host)
        if (p["allowInsecure"] == "1" || p["allowInsecure"] == "true") t.put("insecure", true)
        p["alpn"]?.takeIf { it.isNotBlank() }?.let { a ->
            t.put("alpn", JSONArray(a.split(",").map { it.trim() }.filter { it.isNotEmpty() }))
        }
        val fp = p["fp"]?.takeIf { it.isNotBlank() }
        if (security == "reality") {
            t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp ?: "chrome"))
            t.put("reality", JSONObject().put("enabled", true)
                .put("public_key", p["pbk"] ?: "").put("short_id", p["sid"] ?: ""))
        } else if (fp != null) {
            t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp))
        }
        return t
    }

    private fun transport(p: Map<String, String>): JSONObject? {
        val host = p["requestHost"]?.takeIf { it.isNotBlank() }
        val path = p["path"]?.takeIf { it.isNotBlank() }
        return when (p["network"]?.lowercase()) {
            "ws" -> JSONObject().put("type", "ws").put("path", path ?: "/").apply {
                host?.let { put("headers", JSONObject().put("Host", it)) }
            }
            "grpc" -> JSONObject().put("type", "grpc").put("service_name", p["serviceName"] ?: "")
            "http", "h2" -> JSONObject().put("type", "http").put("path", path ?: "/").apply {
                host?.let { put("host", JSONArray().put(it)) }
            }
            "httpupgrade" -> JSONObject().put("type", "httpupgrade").put("path", path ?: "/").apply {
                host?.let { put("host", it) }
            }
            else -> null // tcp
        }
    }
}
