package com.kanis.vpn.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kanis.vpn.databinding.ItemProfileBinding
import com.kanis.vpn.model.Profile

class ProfilesAdapter(
    private val items: MutableList<Profile>,
    private val onClick: (Profile) -> Unit,
    private val onMoreClick: (Profile, View) -> Unit
) : RecyclerView.Adapter<ProfilesAdapter.VH>() {

    inner class VH(val binding: ItemProfileBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemProfileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val profile = items[position]
        holder.binding.txtRemark.text = profile.remark.ifBlank { profile.host }
        holder.binding.txtHostPort.text = "${profile.host}:${profile.port}"
        val flags = MainActivity.flagsOf(holder.binding.root.context, profile)
        holder.binding.txtProtocol.text =
            profile.protocol.displayName.uppercase() + if (flags.isEmpty()) "" else " · $flags"
        holder.binding.imgLockIcon.visibility = if (profile.locked) View.VISIBLE else View.GONE
        holder.binding.root.setOnClickListener { onClick(profile) }
        holder.binding.imgMore.setOnClickListener { onMoreClick(profile, it) }
    }

    override fun getItemCount(): Int = items.size

    fun update(newItems: List<Profile>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
