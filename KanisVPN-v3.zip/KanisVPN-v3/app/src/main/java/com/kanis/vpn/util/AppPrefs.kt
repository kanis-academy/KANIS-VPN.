package com.kanis.vpn.util

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/** Tiny settings store: theme (light by default) and which profile is the current one. */
object AppPrefs {
    private const val FILE = "kanis_prefs"
    private const val KEY_DARK = "dark_theme"
    private const val KEY_CURRENT = "current_profile_id"

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isDark(c: Context): Boolean = prefs(c).getBoolean(KEY_DARK, false)

    fun setDark(c: Context, dark: Boolean) {
        prefs(c).edit().putBoolean(KEY_DARK, dark).apply()
        applyTheme(c)
    }

    /** Light unless the user switched to dark; the phone's own theme setting is ignored on purpose. */
    fun applyTheme(c: Context) {
        AppCompatDelegate.setDefaultNightMode(
            if (isDark(c)) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    fun currentId(c: Context): String? = prefs(c).getString(KEY_CURRENT, null)

    fun setCurrentId(c: Context, id: String?) {
        prefs(c).edit().putString(KEY_CURRENT, id).apply()
    }
}
