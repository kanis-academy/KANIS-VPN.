package com.kanis.vpn.profile

import android.content.Context
import com.kanis.vpn.model.Profile
import org.json.JSONArray
import java.io.File

/**
 * Simple file-backed profile store (no external DB needed). Lives in app-private storage,
 * so it disappears with the app and is never readable by other apps.
 */
class ProfileRepository(context: Context) {

    private val file = File(context.filesDir, "profiles.json")

    @Synchronized
    fun loadAll(): MutableList<Profile> {
        if (!file.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(file.readText())
            MutableList(arr.length()) { i -> Profile.fromJson(arr.getJSONObject(i)) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun saveAll(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach { arr.put(it.toJson()) }
        file.writeText(arr.toString())
    }

    @Synchronized
    fun upsert(profile: Profile) {
        val all = loadAll()
        val index = all.indexOfFirst { it.id == profile.id }
        if (index >= 0) {
            val existing = all[index]
            if (existing.locked) {
                // Locked is permanent: a locked profile is never rewritten.
                return
            }
            all[index] = profile
        } else {
            all.add(profile)
        }
        saveAll(all)
    }

    @Synchronized
    fun delete(profileId: String) {
        val all = loadAll()
        all.removeAll { it.id == profileId }
        saveAll(all)
    }

    /** Locks a profile for good. There is deliberately no way back. */
    @Synchronized
    fun lock(profileId: String): Profile? {
        val all = loadAll()
        val index = all.indexOfFirst { it.id == profileId }
        if (index < 0) return null
        val p = all[index]
        if (!p.locked) {
            p.locked = true
            p.lockedAtEpochMs = System.currentTimeMillis()
            all[index] = p
            saveAll(all)
        }
        return p
    }

    fun get(profileId: String?): Profile? = if (profileId == null) null else loadAll().firstOrNull { it.id == profileId }
}
