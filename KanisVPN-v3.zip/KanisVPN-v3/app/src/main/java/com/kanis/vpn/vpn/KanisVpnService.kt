package com.kanis.vpn.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.TrafficStats as AndroidTraffic
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.kanis.vpn.R
import com.kanis.vpn.model.ParamSpecs
import com.kanis.vpn.model.Profile
import com.kanis.vpn.model.Protocol
import com.kanis.vpn.ui.MainActivity
import org.json.JSONObject

/**
 * Owns the connection lifecycle for every protocol. The engine (sing-box or WireGuard) opens
 * the TUN itself through this VpnService; this class validates the profile, runs the engine on
 * a worker thread, shows the foreground notification and broadcasts status + throughput.
 */
class KanisVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.kanis.vpn.action.CONNECT"
        const val ACTION_DISCONNECT = "com.kanis.vpn.action.DISCONNECT"
        const val EXTRA_PROFILE_JSON = "profile_json"

        const val ACTION_STATUS = "com.kanis.vpn.STATUS"
        const val EXTRA_STATUS = "status"
        const val EXTRA_RX = "rx"
        const val EXTRA_TX = "tx"
        const val STATUS_CONNECTING = "connecting"
        const val STATUS_CONNECTED = "connected"
        const val STATUS_DISCONNECTED = "disconnected"
        const val STATUS_ERROR = "error"

        private const val CHANNEL_ID = "kanis_vpn_channel"
        private const val NOTIF_ID = 42
    }

    @Volatile private var engine: VpnEngine? = null
    private val ui = Handler(Looper.getMainLooper())
    private var statsRunnable: Runnable? = null
    private var lastRx = 0L
    private var lastTx = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val json = intent.getStringExtra(EXTRA_PROFILE_JSON)
                if (json != null) connect(Profile.fromJson(JSONObject(json)))
            }
            ACTION_DISCONNECT -> teardown(notify = true)
        }
        return START_NOT_STICKY
    }

    private fun connect(profile: Profile) {
        broadcastStatus(STATUS_CONNECTING)
        showForeground("Connecting…")

        Thread {
            try {
                engine?.stop() // a previous session, if any
                if (profile.isExpired()) throw IllegalArgumentException(getString(R.string.toast_expired, profile.expires))
                val missing = ParamSpecs.required(profile.protocol).firstOrNull { profile.params[it].isNullOrBlank() }
                if (missing != null) throw IllegalArgumentException(getString(R.string.toast_missing_param, missing))
                if (profile.protocol == Protocol.SSH_TUNNEL &&
                    profile.params["password"].isNullOrBlank() && profile.params["privateKey"].isNullOrBlank()
                ) throw IllegalArgumentException(getString(R.string.toast_missing_param, "password / private key"))

                val e = VpnEngineFactory.create(this, profile.protocol)
                engine = e
                e.start(profile, this)

                showForeground("Connected")
                broadcastStatus(STATUS_CONNECTED)
                ui.post { startStatsLoop() }
            } catch (t: Throwable) {
                broadcastStatus(STATUS_ERROR, t.message ?: t.javaClass.simpleName)
                ui.post { teardown(notify = false) }
            }
        }.start()
    }

    // ---------- throughput (uid counters: tunnel traffic leaves the app uid) ----------

    private fun startStatsLoop() {
        stopStatsLoop()
        val uid = Process.myUid()
        lastRx = AndroidTraffic.getUidRxBytes(uid).coerceAtLeast(0)
        lastTx = AndroidTraffic.getUidTxBytes(uid).coerceAtLeast(0)
        val r = object : Runnable {
            override fun run() {
                val rx = AndroidTraffic.getUidRxBytes(uid).coerceAtLeast(0)
                val tx = AndroidTraffic.getUidTxBytes(uid).coerceAtLeast(0)
                broadcastStats(TrafficStats(rx - lastRx, tx - lastTx).let { it })
                lastRx = rx; lastTx = tx
                ui.postDelayed(this, 1000)
            }
        }
        statsRunnable = r
        ui.postDelayed(r, 1000)
    }

    private fun stopStatsLoop() {
        statsRunnable?.let { ui.removeCallbacks(it) }
        statsRunnable = null
    }

    private fun teardown(notify: Boolean) {
        stopStatsLoop()
        val e = engine
        engine = null
        Thread { try { e?.stop() } catch (ex: Exception) {} }.start()
        if (notify) broadcastStatus(STATUS_DISCONNECTED)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopStatsLoop()
        try { engine?.stop() } catch (ex: Exception) {}
        engine = null
        super.onDestroy()
    }

    override fun onRevoke() {
        teardown(notify = true)
        super.onRevoke()
    }

    // ---------- broadcasts & notification ----------

    private fun broadcastStatus(status: String, message: String? = null) {
        sendBroadcast(Intent(ACTION_STATUS).apply {
            putExtra(EXTRA_STATUS, status)
            message?.let { putExtra("message", it) }
            setPackage(packageName)
        })
    }

    private fun broadcastStats(stats: TrafficStats) {
        sendBroadcast(Intent(ACTION_STATUS).apply {
            putExtra(EXTRA_STATUS, STATUS_CONNECTED)
            putExtra(EXTRA_RX, stats.rxBytesPerSec)
            putExtra(EXTRA_TX, stats.txBytesPerSec)
            setPackage(packageName)
        })
    }

    private fun showForeground(text: String) {
        val n = buildNotification(text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(text: String): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(NotificationChannel(CHANNEL_ID, "KANIS VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("KANIS VPN").setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(contentIntent).setOngoing(true).build()
    }
}
