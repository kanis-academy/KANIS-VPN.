package com.kanis.vpn.util

import android.util.Base64
import com.kanis.vpn.model.Profile
import com.kanis.vpn.model.Protocol
import org.json.JSONObject
import java.net.URLDecoder

/**
 * Turns pasted links into [Profile]s: vmess://, vless://, ss://, trojan://, hysteria2:// (hy2://),
 * tuic://, ssh://, a wg-quick [Interface]/[Peer] block, or a whole subscription
 * (several links, one per line, optionally base64-encoded).
 */
object ConfigLinkParser {

    /** First profile found, or null. */
    fun parse(raw: String): Profile? = parseAll(raw).firstOrNull()

    fun parseAll(raw: String): List<Profile> {
        val text = raw.trim()
        if (text.isEmpty()) return emptyList()
        if (text.startsWith("# KANIS VPN profile")) {
            return listOfNotNull(runCatching { parseExport(text) }.getOrNull())
        }
        if (text.contains("[Interface]") && text.contains("[Peer]")) {
            return listOfNotNull(runCatching { parseWireGuard(text) }.getOrNull())
        }
        var lines = splitLines(text)
        if (lines.none { it.contains("://") }) {
            val decoded = decodeBase64(text)
            if (decoded != null) lines = splitLines(decoded)
        }
        return lines.mapNotNull { runCatching { parseLink(it) }.getOrNull() }
    }

    /** A file exported by KANIS VPN: key=value lines. Lock, expiry and re-share rules travel with it. */
    private fun parseExport(text: String): Profile? {
        val meta = setOf("remark", "username", "protocol", "host", "port", "locked", "locked_at", "expires", "no_reshare")
        val m = mutableMapOf<String, String>()
        val params = mutableMapOf<String, String>()
        text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") && it.contains("=") }.forEach {
            val k = it.substringBefore("=")
            val v = it.substringAfter("=")
            if (k in meta) m[k] = v else if (v.isNotEmpty()) params[k] = v
        }
        val protocol = runCatching { Protocol.valueOf(m["protocol"] ?: "") }.getOrNull() ?: return null
        val host = m["host"].orEmpty()
        if (host.isBlank()) return null
        return Profile(
            username = m["username"].orEmpty(), remark = m["remark"].orEmpty().ifBlank { host },
            host = host, port = m["port"]?.toIntOrNull() ?: 443, protocol = protocol, params = params,
            locked = m["locked"] == "1",
            lockedAtEpochMs = if (m["locked"] == "1") (m["locked_at"]?.toLongOrNull() ?: System.currentTimeMillis()) else null,
            expires = m["expires"].orEmpty(), noReshare = m["no_reshare"] == "1", imported = true
        )
    }

    private fun splitLines(t: String) = t.lines().map { it.trim() }.filter { it.isNotEmpty() }

    private fun parseLink(link: String): Profile? {
        val scheme = link.substringBefore("://", "").lowercase()
        return when (Protocol.fromUriScheme(scheme)) {
            Protocol.VMESS -> parseVmess(link)
            Protocol.VLESS -> parseVless(link)
            Protocol.SHADOWSOCKS -> parseShadowsocks(link)
            Protocol.TROJAN -> parseTrojan(link)
            Protocol.HYSTERIA2 -> parseHysteria2(link)
            Protocol.TUIC -> parseTuic(link)
            Protocol.SSH_TUNNEL -> parseSsh(link)
            else -> null
        }
    }

    // ---------- generic URI split: scheme://userinfo@host:port?query#fragment ----------

    private class Uri(val userInfo: String, val host: String, val port: Int?, val query: Map<String, String>, val fragment: String)

    private fun splitUri(link: String): Uri {
        var rest = link.substringAfter("://")
        val fragment = if (rest.contains("#")) dec(rest.substringAfter("#")) else ""
        rest = rest.substringBefore("#")
        val query = if (rest.contains("?")) parseQuery(rest.substringAfter("?")) else emptyMap()
        rest = rest.substringBefore("?").trimEnd('/')
        val userInfo = if (rest.contains("@")) rest.substringBeforeLast("@") else ""
        val hostPort = if (rest.contains("@")) rest.substringAfterLast("@") else rest
        val host: String
        val port: Int?
        if (hostPort.startsWith("[")) { // IPv6
            host = hostPort.substringAfter("[").substringBefore("]")
            port = hostPort.substringAfter("]", "").removePrefix(":").toIntOrNull()
        } else {
            host = hostPort.substringBeforeLast(":")
            port = if (hostPort.contains(":")) hostPort.substringAfterLast(":").toIntOrNull() else null
        }
        return Uri(userInfo, host, port, query, fragment)
    }

    private fun parseQuery(q: String): Map<String, String> =
        q.split("&").filter { it.contains("=") }.associate {
            dec(it.substringBefore("=")) to dec(it.substringAfter("="))
        }

    private fun dec(s: String) = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    /** Base64 decoder tolerant to the URL-safe alphabet and to missing padding. */
    fun decodeBase64(s: String): String? {
        var clean = s.trim().replace("\n", "").replace("\r", "").replace("=", "")
        while (clean.length % 4 != 0) clean += "="
        for (flags in intArrayOf(Base64.DEFAULT, Base64.URL_SAFE)) {
            try { return String(Base64.decode(clean, flags)) } catch (e: IllegalArgumentException) { /* try next */ }
        }
        return null
    }

    /** Maps the query keys shared by vless/trojan links onto our internal param names. */
    private fun commonStream(q: Map<String, String>): MutableMap<String, String> {
        val m = mutableMapOf<String, String>()
        fun put(dst: String, vararg src: String) {
            src.firstNotNullOfOrNull { q[it]?.takeIf { v -> v.isNotBlank() } }?.let { m[dst] = it }
        }
        put("network", "type", "net")
        put("security", "security")
        put("sni", "sni", "peer", "serverName")
        put("alpn", "alpn")
        put("fp", "fp")
        put("allowInsecure", "allowInsecure", "insecure")
        put("pbk", "pbk")
        put("sid", "sid")
        put("flow", "flow")
        put("path", "path")
        put("requestHost", "host")
        put("serviceName", "serviceName")
        put("encryption", "encryption")
        return m
    }

    // ---------- protocols ----------

    private fun parseVmess(text: String): Profile {
        val payload = text.substringAfter("://").substringBefore("#")
        val json = JSONObject(decodeBase64(payload) ?: error("bad vmess base64"))
        val tls = json.optString("tls", "")
        val params = mutableMapOf(
            "uuid" to json.optString("id"),
            "alterId" to json.optString("aid", "0"),
            "network" to json.optString("net", "tcp"),
            "path" to json.optString("path", ""),
            "requestHost" to json.optString("host", ""),
            "security" to if (tls.equals("tls", true)) "tls" else "none",
            "sni" to json.optString("sni", ""),
            "alpn" to json.optString("alpn", ""),
            "fp" to json.optString("fp", "")
        )
        return Profile(
            username = "imported", remark = json.optString("ps", "Imported VMess"),
            host = json.optString("add"), port = json.optString("port", "443").toIntOrNull() ?: 443,
            protocol = Protocol.VMESS, params = params.filterValues { it.isNotEmpty() }.toMutableMap()
        )
    }

    private fun parseVless(text: String): Profile {
        val u = splitUri(text)
        val params = commonStream(u.query)
        params["uuid"] = u.userInfo
        return Profile(
            username = "imported", remark = u.fragment.ifBlank { "Imported VLESS" },
            host = u.host, port = u.port ?: 443, protocol = Protocol.VLESS, params = params
        )
    }

    private fun parseTrojan(text: String): Profile {
        val u = splitUri(text)
        val params = commonStream(u.query)
        params["password"] = dec(u.userInfo)
        if (!params.containsKey("security")) params["security"] = "tls"
        return Profile(
            username = "imported", remark = u.fragment.ifBlank { "Imported Trojan" },
            host = u.host, port = u.port ?: 443, protocol = Protocol.TROJAN, params = params
        )
    }

    /** Handles SIP002 (base64(method:pass)@host:port or method:pass@host:port) and the legacy all-base64 form. */
    private fun parseShadowsocks(text: String): Profile {
        var rest = text.substringAfter("://")
        val remark = if (rest.contains("#")) dec(rest.substringAfter("#")) else "Imported Shadowsocks"
        rest = rest.substringBefore("#")
        val plugin = if (rest.contains("?")) parseQuery(rest.substringAfter("?"))["plugin"] else null
        rest = rest.substringBefore("?").trimEnd('/')

        val methodPassword: String
        val hostPort: String
        if (rest.contains("@")) {
            val userInfo = rest.substringBeforeLast("@")
            hostPort = rest.substringAfterLast("@")
            methodPassword = if (userInfo.contains(":")) dec(userInfo) else decodeBase64(userInfo) ?: error("bad ss")
        } else {
            val decoded = decodeBase64(rest) ?: error("bad ss")
            methodPassword = decoded.substringBeforeLast("@")
            hostPort = decoded.substringAfterLast("@")
        }
        val params = mutableMapOf(
            "method" to methodPassword.substringBefore(":"),
            "password" to methodPassword.substringAfter(":")
        )
        if (!plugin.isNullOrBlank()) {
            params["plugin"] = plugin.substringBefore(";")
            params["pluginOpts"] = plugin.substringAfter(";", "")
        }
        return Profile(
            username = "imported", remark = remark,
            host = hostPort.substringBeforeLast(":").trim('[', ']'),
            port = hostPort.substringAfterLast(":").toIntOrNull() ?: 8388,
            protocol = Protocol.SHADOWSOCKS, params = params
        )
    }

    private fun parseHysteria2(text: String): Profile {
        val u = splitUri(text)
        val q = u.query
        val params = mutableMapOf("password" to dec(u.userInfo))
        q["sni"]?.let { params["sni"] = it }
        q["obfs"]?.let { params["obfs"] = it }
        q["obfs-password"]?.let { params["obfsPassword"] = it }
        (q["insecure"] ?: q["allowInsecure"])?.let { params["allowInsecure"] = it }
        q["upmbps"]?.let { params["upMbps"] = it }
        q["downmbps"]?.let { params["downMbps"] = it }
        return Profile(
            username = "imported", remark = u.fragment.ifBlank { "Imported Hysteria2" },
            host = u.host, port = u.port ?: 443, protocol = Protocol.HYSTERIA2, params = params
        )
    }

    private fun parseTuic(text: String): Profile {
        val u = splitUri(text)
        val params = mutableMapOf(
            "uuid" to u.userInfo.substringBefore(":"),
            "password" to dec(u.userInfo.substringAfter(":", ""))
        )
        u.query["sni"]?.let { params["sni"] = it }
        u.query["alpn"]?.let { params["alpn"] = it }
        u.query["congestion_control"]?.let { params["congestion"] = it }
        u.query["udp_relay_mode"]?.let { params["udpRelayMode"] = it }
        (u.query["allow_insecure"] ?: u.query["allowInsecure"])?.let { params["allowInsecure"] = it }
        return Profile(
            username = "imported", remark = u.fragment.ifBlank { "Imported TUIC" },
            host = u.host, port = u.port ?: 443, protocol = Protocol.TUIC, params = params
        )
    }

    private fun parseSsh(text: String): Profile {
        val u = splitUri(text)
        val params = mutableMapOf("password" to dec(u.userInfo.substringAfter(":", "")))
        return Profile(
            username = dec(u.userInfo.substringBefore(":")),
            remark = u.fragment.ifBlank { "Imported SSH" },
            host = u.host, port = u.port ?: 22, protocol = Protocol.SSH_TUNNEL, params = params
        )
    }

    private fun parseWireGuard(text: String): Profile {
        val lines = text.lines().map { it.trim() }
        fun value(key: String): String =
            lines.firstOrNull { it.startsWith("$key =", true) || it.startsWith("$key=", true) }
                ?.substringAfter("=")?.trim() ?: ""
        val endpoint = value("Endpoint")
        return Profile(
            username = "imported", remark = "Imported WireGuard",
            host = endpoint.substringBeforeLast(":").trim('[', ']'),
            port = endpoint.substringAfterLast(":").toIntOrNull() ?: 51820,
            protocol = Protocol.WIREGUARD,
            params = mutableMapOf(
                "privateKey" to value("PrivateKey"), "address" to value("Address"),
                "dns" to value("DNS"), "publicKey" to value("PublicKey"),
                "presharedKey" to value("PresharedKey"), "allowedIPs" to value("AllowedIPs")
            )
        )
    }
}
