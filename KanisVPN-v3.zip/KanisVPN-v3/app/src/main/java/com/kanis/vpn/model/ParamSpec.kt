package com.kanis.vpn.model

/** One editable protocol-specific field shown in the "Protocol settings" dialog. */
data class ParamSpec(val key: String, val label: String, val hint: String = "", val secret: Boolean = false)

object ParamSpecs {
    private val transport = listOf(
        ParamSpec("network", "Transport", "tcp | ws | grpc | http | httpupgrade"),
        ParamSpec("path", "Path", "/"),
        ParamSpec("requestHost", "Host header", "example.com"),
        ParamSpec("serviceName", "gRPC service name")
    )
    private val tls = listOf(
        ParamSpec("security", "Security", "none | tls | reality"),
        ParamSpec("sni", "SNI (server name)"),
        ParamSpec("alpn", "ALPN", "h2,http/1.1"),
        ParamSpec("fp", "uTLS fingerprint", "chrome"),
        ParamSpec("allowInsecure", "Allow insecure", "0 | 1")
    )

    fun forProtocol(p: Protocol): List<ParamSpec> = when (p) {
        Protocol.VMESS -> listOf(ParamSpec("uuid", "UUID"), ParamSpec("alterId", "Alter ID", "0")) + transport + tls
        Protocol.VLESS -> listOf(ParamSpec("uuid", "UUID"), ParamSpec("flow", "Flow", "xtls-rprx-vision")) +
            transport + tls + listOf(ParamSpec("pbk", "Reality public key"), ParamSpec("sid", "Reality short ID"))
        Protocol.TROJAN -> listOf(ParamSpec("password", "Password", secret = true)) + transport + tls
        Protocol.SHADOWSOCKS -> listOf(
            ParamSpec("method", "Method", "aes-256-gcm | chacha20-ietf-poly1305 | 2022-blake3-aes-128-gcm"),
            ParamSpec("password", "Password", secret = true),
            ParamSpec("plugin", "Plugin", "obfs-local | v2ray-plugin"),
            ParamSpec("pluginOpts", "Plugin options")
        )
        Protocol.HYSTERIA2 -> listOf(
            ParamSpec("password", "Password", secret = true),
            ParamSpec("obfs", "Obfuscation", "salamander"),
            ParamSpec("obfsPassword", "Obfuscation password", secret = true),
            ParamSpec("upMbps", "Upload Mbps"), ParamSpec("downMbps", "Download Mbps"),
            ParamSpec("sni", "SNI (server name)"), ParamSpec("allowInsecure", "Allow insecure", "0 | 1")
        )
        Protocol.TUIC -> listOf(
            ParamSpec("uuid", "UUID"), ParamSpec("password", "Password", secret = true),
            ParamSpec("congestion", "Congestion control", "bbr"),
            ParamSpec("udpRelayMode", "UDP relay mode", "native | quic"),
            ParamSpec("sni", "SNI (server name)"), ParamSpec("alpn", "ALPN", "h3"),
            ParamSpec("allowInsecure", "Allow insecure", "0 | 1")
        )
        Protocol.SSH_TUNNEL -> listOf(
            ParamSpec("password", "Password", secret = true),
            ParamSpec("privateKey", "Private key (PEM, optional)", secret = true)
        )
        Protocol.WIREGUARD -> listOf(
            ParamSpec("privateKey", "Private key", secret = true),
            ParamSpec("address", "Interface address", "10.0.0.2/32"),
            ParamSpec("dns", "DNS", "1.1.1.1"),
            ParamSpec("publicKey", "Peer public key"),
            ParamSpec("presharedKey", "Preshared key (optional)", secret = true),
            ParamSpec("allowedIPs", "Allowed IPs", "0.0.0.0/0, ::/0")
        )
    }

    /** Keys that must be filled for the protocol to be able to connect. */
    fun required(p: Protocol): List<String> = when (p) {
        Protocol.VMESS, Protocol.VLESS -> listOf("uuid")
        Protocol.TROJAN, Protocol.HYSTERIA2 -> listOf("password")
        Protocol.SHADOWSOCKS -> listOf("method", "password")
        Protocol.TUIC -> listOf("uuid", "password")
        Protocol.SSH_TUNNEL -> emptyList() // password OR key, checked in the engine
        Protocol.WIREGUARD -> listOf("privateKey", "publicKey")
    }
}
