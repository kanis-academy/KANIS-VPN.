package com.kanis.vpn.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.kanis.vpn.R
import com.kanis.vpn.databinding.ActivityProfilesBinding
import com.kanis.vpn.model.Profile
import com.kanis.vpn.profile.ProfileRepository
import com.kanis.vpn.util.AppPrefs

class ProfilesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfilesBinding
    private lateinit var repo: ProfileRepository
    private lateinit var adapter: ProfilesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfilesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = ProfileRepository(this)

        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = ProfilesAdapter(
            items = mutableListOf(),
            onClick = { profile -> openProfile(profile) },
            onMoreClick = { profile, anchor -> showMenu(profile, anchor) }
        )
        binding.recyclerProfiles.layoutManager = LinearLayoutManager(this)
        binding.recyclerProfiles.adapter = adapter

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val all = repo.loadAll()
        adapter.update(all)
        binding.txtEmpty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openProfile(profile: Profile) {
        AppPrefs.setCurrentId(this, profile.id)
        setResult(RESULT_OK, Intent().putExtra("profile_id", profile.id))
        finish()
    }

    private fun showMenu(profile: Profile, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_profile_item, popup.menu)
        popup.menu.findItem(R.id.action_share).isEnabled = profile.canExport()

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_use -> {
                    openProfile(profile)
                    true
                }
                R.id.action_edit -> {
                    startActivity(
                        Intent(this, ProfileEditorActivity::class.java)
                            .putExtra(ProfileEditorActivity.EXTRA_PROFILE_ID, profile.id)
                    )
                    true
                }
                R.id.action_share -> {
                    // Export locks the profile first, for good, then shares the locked file.
                    var p = profile
                    if (!p.locked) {
                        p = ProfileEditorActivity.lockAndStore(repo, p)
                        Toast.makeText(this, R.string.toast_locked_exported, Toast.LENGTH_SHORT).show()
                        refresh()
                    }
                    ProfileEditorActivity.shareProfile(this, p)
                    true
                }
                R.id.action_delete -> {
                    repo.delete(profile.id)
                    if (AppPrefs.currentId(this) == profile.id) AppPrefs.setCurrentId(this, null)
                    Toast.makeText(this, R.string.toast_deleted, Toast.LENGTH_SHORT).show()
                    refresh()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }
}
