package com.kanis.vpn.vpn

import android.content.Context
import com.kanis.vpn.model.Protocol

object VpnEngineFactory {
    fun create(context: Context, protocol: Protocol): VpnEngine =
        if (protocol == Protocol.WIREGUARD) WireGuardEngine(context) else SingBoxEngine(context)
}
