package com.kanis.vpn.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import com.kanis.vpn.R
import com.kanis.vpn.databinding.ActivityMainBinding
import com.kanis.vpn.model.Profile
import com.kanis.vpn.profile.ProfileRepository
import com.kanis.vpn.util.AppPrefs
import com.kanis.vpn.util.PublicIpFetcher
import com.kanis.vpn.vpn.KanisVpnService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Home screen: status, Connect, current profile, public IP, throughput. Editing lives in [ProfileEditorActivity]. */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repo: ProfileRepository

    private var currentProfile: Profile? = null
    private var connected = false
    private var connectingStartMs = 0L
    private val timerHandler = Handler(Looper.getMainLooper())
    private var timerRunnable: Runnable? = null
    private val uiScope = CoroutineScope(Dispatchers.Main + Job())

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) startVpnService() else Toast.makeText(
            this, getString(R.string.permission_vpn_rationale), Toast.LENGTH_LONG
        ).show()
    }

    private val editorLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        loadCurrent()
        // "copy -> import -> connect": the editor asks us to connect right after an import.
        if (result.data?.getBooleanExtra(ProfileEditorActivity.EXTRA_CONNECT, false) == true) onConnectClicked()
    }

    private val profilesLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { loadCurrent() }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op either way, foreground service still runs */ }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != KanisVpnService.ACTION_STATUS) return
            when (intent.getStringExtra(KanisVpnService.EXTRA_STATUS)) {
                KanisVpnService.STATUS_CONNECTING -> setConnectingUi()
                KanisVpnService.STATUS_CONNECTED -> {
                    setConnectedUi()
                    val rx = intent.getLongExtra(KanisVpnService.EXTRA_RX, 0)
                    val tx = intent.getLongExtra(KanisVpnService.EXTRA_TX, 0)
                    binding.txtDownload.text = formatSpeed(rx)
                    binding.txtUpload.text = formatSpeed(tx)
                }
                KanisVpnService.STATUS_DISCONNECTED -> setDisconnectedUi()
                KanisVpnService.STATUS_ERROR -> {
                    setDisconnectedUi()
                    val msg = intent.getStringExtra("message")
                    Toast.makeText(this@MainActivity, msg ?: "Connection error", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = ProfileRepository(this)

        setDisconnectedUi()
        setupDrawer()

        binding.btnConnect.setOnClickListener { onConnectClicked() }
        binding.btnMenu.setOnClickListener { binding.drawerLayout.openDrawer(GravityCompat.START) }
        binding.btnProfile.setOnClickListener { openEditor() }
        binding.cardProfile.setOnClickListener { openEditor() }

        val pkgName = packageName
        val version = try { packageManager.getPackageInfo(pkgName, 0).versionName ?: "" } catch (e: Exception) { "" }
        binding.txtAppIdFooter.text = getString(R.string.app_id_footer, pkgName, version)
        binding.txtAppIdDrawer.text = getString(R.string.app_id_drawer, pkgName, version)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        requestNotificationPermissionIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(KanisVpnService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, filter)
        }
    }

    override fun onResume() {
        super.onResume()
        loadCurrent()
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(statusReceiver) } catch (e: Exception) { /* not registered */ }
    }

    override fun onDestroy() {
        stopTimer()
        uiScope.cancel()
        super.onDestroy()
    }

    // ---------- Drawer ----------

    private fun setupDrawer() {
        binding.switchDark.isChecked = AppPrefs.isDark(this)
        binding.switchDark.setOnCheckedChangeListener { _, checked ->
            if (checked != AppPrefs.isDark(this)) AppPrefs.setDark(this, checked) // recreates the screen
        }
        binding.drawerHome.setOnClickListener { binding.drawerLayout.closeDrawer(GravityCompat.START) }
        binding.drawerProfile.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            openEditor()
        }
        binding.drawerProfiles.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            profilesLauncher.launch(Intent(this, ProfilesActivity::class.java))
        }
    }

    private fun openEditor() {
        val intent = Intent(this, ProfileEditorActivity::class.java)
        currentProfile?.let { intent.putExtra(ProfileEditorActivity.EXTRA_PROFILE_ID, it.id) }
        editorLauncher.launch(intent)
    }

    // ---------- Current profile ----------

    private fun loadCurrent() {
        val all = repo.loadAll()
        currentProfile = all.firstOrNull { it.id == AppPrefs.currentId(this) } ?: all.lastOrNull()
        currentProfile?.let { AppPrefs.setCurrentId(this, it.id) }
        renderCurrent()
    }

    private fun renderCurrent() {
        val p = currentProfile
        if (p == null) {
            binding.txtProfileName.text = getString(R.string.no_profile)
            binding.txtProfileHost.text = getString(R.string.no_profile_hint)
            binding.txtProfileFlags.visibility = View.GONE
            return
        }
        binding.txtProfileName.text = p.remark.ifBlank { p.host }
        binding.txtProfileHost.text = "${p.host}:${p.port} · ${p.protocol.displayName}"
        val flags = flagsOf(this, p)
        binding.txtProfileFlags.text = flags
        binding.txtProfileFlags.visibility = if (flags.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------- Connect ----------

    private fun onConnectClicked() {
        if (connected) {
            stopVpnService()
            return
        }
        val p = currentProfile
        if (p == null || p.host.isBlank()) {
            Toast.makeText(this, R.string.toast_add_profile_first, Toast.LENGTH_SHORT).show()
            return
        }
        if (p.isExpired()) {
            Toast.makeText(this, getString(R.string.toast_expired, p.expires), Toast.LENGTH_LONG).show()
            return
        }
        val vpnIntent = VpnService.prepare(this)
        if (vpnIntent != null) {
            vpnPermissionLauncher.launch(vpnIntent)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        val p = currentProfile ?: return
        setConnectingUi()
        val intent = Intent(this, KanisVpnService::class.java).apply {
            action = KanisVpnService.ACTION_CONNECT
            putExtra(KanisVpnService.EXTRA_PROFILE_JSON, p.toJson().toString())
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopVpnService() {
        val intent = Intent(this, KanisVpnService::class.java).apply {
            action = KanisVpnService.ACTION_DISCONNECT
        }
        startService(intent)
    }

    // ---------- Status UI ----------

    private fun setConnectingUi() {
        connected = false
        binding.txtStatus.text = getString(R.string.status_connecting)
        binding.txtStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_gold_500))
        binding.btnConnect.text = getString(R.string.status_connecting)
        binding.progressWheel.visibility = View.VISIBLE
        binding.txtFooterStatus.text = getString(R.string.status_connecting)
        binding.txtFooterStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_gold_500))
        binding.imgUpdateDot.visibility = View.INVISIBLE
    }

    private fun setConnectedUi() {
        val first = !connected
        connected = true
        binding.txtStatus.text = getString(R.string.status_connected)
        binding.txtStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_green))
        binding.btnConnect.text = getString(R.string.btn_disconnect)
        binding.progressWheel.visibility = View.INVISIBLE
        binding.txtFooterStatus.text = getString(R.string.status_connected)
        binding.txtFooterStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_green))
        binding.imgUpdateDot.visibility = View.VISIBLE
        if (first) { // the service re-broadcasts every second; start the timer and IP lookup once
            startTimer()
            fetchPublicIp()
        }
    }

    private fun setDisconnectedUi() {
        connected = false
        binding.txtStatus.text = getString(R.string.status_disconnected)
        binding.txtStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_red))
        binding.btnConnect.text = getString(R.string.btn_connect)
        binding.progressWheel.visibility = View.INVISIBLE
        binding.txtFooterStatus.text = getString(R.string.status_check_credentials)
        binding.txtFooterStatus.setTextColor(ContextCompat.getColor(this, R.color.kanis_red))
        binding.imgUpdateDot.visibility = View.INVISIBLE
        binding.txtDownload.text = "0 kb/s"
        binding.txtUpload.text = "0 kb/s"
        binding.txtIpValue.text = getString(R.string.label_not_connected)
        stopTimer()
    }

    // ---------- Session timer ----------

    private fun startTimer() {
        stopTimer()
        connectingStartMs = System.currentTimeMillis()
        val runnable = object : Runnable {
            override fun run() {
                val elapsed = (System.currentTimeMillis() - connectingStartMs) / 1000
                val h = elapsed / 3600
                val m = (elapsed % 3600) / 60
                val s = elapsed % 60
                binding.txtTimer.text = String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
                timerHandler.postDelayed(this, 1000)
            }
        }
        timerRunnable = runnable
        timerHandler.post(runnable)
    }

    private fun stopTimer() {
        timerRunnable?.let { timerHandler.removeCallbacks(it) }
        timerRunnable = null
        binding.txtTimer.text = "00:00:00"
    }

    // ---------- Public IP panel ----------

    private fun fetchPublicIp() {
        uiScope.launch {
            binding.txtIpValue.text = "…"
            val ip = withContext(Dispatchers.IO) { PublicIpFetcher.fetch() }
            binding.txtIpValue.text = ip ?: getString(R.string.label_not_connected)
        }
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        val kb = bytesPerSec / 1024.0
        return if (kb < 1024) String.format(Locale.US, "%.1f kb/s", kb)
        else String.format(Locale.US, "%.2f MB/s", kb / 1024.0)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    companion object {
        /** "LOCKED · EXPIRES 2027-01-31 · NO RE-SHARE" (empty when nothing applies). */
        fun flagsOf(c: Context, p: Profile): String {
            val parts = mutableListOf<String>()
            if (p.locked) parts.add(c.getString(R.string.chip_locked))
            if (p.expires.isNotBlank()) {
                parts.add(
                    if (p.isExpired()) c.getString(R.string.chip_expired, p.expires)
                    else c.getString(R.string.chip_expires, p.expires)
                )
            }
            if (p.noReshare) parts.add(c.getString(R.string.chip_noreshare))
            return parts.joinToString(" · ")
        }
    }
}
