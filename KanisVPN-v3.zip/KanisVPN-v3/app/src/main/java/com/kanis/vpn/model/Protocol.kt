package com.kanis.vpn.model

/**
 * Every tunneling protocol KANIS VPN speaks. All of them except WireGuard run on the
 * embedded sing-box core (libbox); WireGuard runs on the official wireguard-android backend.
 */
enum class Protocol(val displayName: String, val uriSchemes: List<String>) {
    VMESS("VMess (V2Ray)", listOf("vmess")),
    VLESS("VLESS / Reality (Xray)", listOf("vless")),
    SHADOWSOCKS("Shadowsocks", listOf("ss")),
    TROJAN("Trojan", listOf("trojan")),
    HYSTERIA2("Hysteria2", listOf("hysteria2", "hy2")),
    TUIC("TUIC v5", listOf("tuic")),
    SSH_TUNNEL("SSH Tunnel", listOf("ssh")),
    WIREGUARD("WireGuard", emptyList());

    /** True when the sing-box core handles this protocol (everything but WireGuard). */
    val usesSingBox: Boolean get() = this != WIREGUARD

    companion object {
        fun fromUriScheme(scheme: String): Protocol? =
            entries.firstOrNull { p -> p.uriSchemes.any { it.equals(scheme, ignoreCase = true) } }

        fun fromDisplayName(name: String): Protocol =
            entries.firstOrNull { it.displayName == name } ?: VMESS
    }
}
