package com.kanis.vpn.model

import org.json.JSONObject
import java.util.UUID

/**
 * A connection profile. Nothing in here is ever hidden: host, port and every field stay visible
 * and are exported in full, in plain text.
 *
 * [locked] is permanent. Once a profile is locked (by the Lock button, or automatically by Export)
 * it is read-only and nothing in the app can unlock or edit it again; it can only be deleted
 * from this phone. [expires] (yyyy-MM-dd) blocks connecting after that day. [noReshare] is
 * honoured on the phone that imports the file: it cannot export it again.
 */
data class Profile(
    val id: String = UUID.randomUUID().toString(),
    var username: String = "",
    var remark: String = "",
    var host: String = "",
    var port: Int = 443,
    var protocol: Protocol = Protocol.VMESS,
    /** Protocol-specific fields (uuid, password, publicKey, presharedKey, network, path, tls...) */
    var params: MutableMap<String, String> = mutableMapOf(),
    var locked: Boolean = false,
    var lockedAtEpochMs: Long? = null,
    var expires: String = "",
    var noReshare: Boolean = false,
    var imported: Boolean = false,
    val createdAtEpochMs: Long = System.currentTimeMillis()
) {

    /** True once the expiry day (end of day, phone time) has passed. */
    fun isExpired(): Boolean {
        if (expires.isBlank()) return false
        return try {
            val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).apply { isLenient = false }
            val day = fmt.parse(expires) ?: return false
            System.currentTimeMillis() >= day.time + 24L * 60 * 60 * 1000
        } catch (e: Exception) { false }
    }

    /** Re-sharing is refused for a locked, imported file whose author blocked it. */
    fun canExport(): Boolean = !(imported && noReshare)


    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("username", username)
        put("remark", remark)
        put("host", host)
        put("port", port)
        put("protocol", protocol.name)
        put("params", JSONObject(params as Map<*, *>))
        put("locked", locked)
        put("lockedAtEpochMs", lockedAtEpochMs ?: JSONObject.NULL)
        put("expires", expires)
        put("noReshare", noReshare)
        put("imported", imported)
        put("createdAtEpochMs", createdAtEpochMs)
    }

    /** Plain-text export. Always complete (host included). An exported file is always a locked one. */
    fun toExportText(): String {
        val sb = StringBuilder()
        sb.appendLine("# KANIS VPN profile")
        sb.appendLine("remark=$remark")
        sb.appendLine("username=$username")
        sb.appendLine("protocol=${protocol.name}")
        sb.appendLine("host=$host")
        sb.appendLine("port=$port")
        params.forEach { (k, v) -> sb.appendLine("$k=$v") }
        sb.appendLine("locked=1")
        sb.appendLine("locked_at=${lockedAtEpochMs ?: System.currentTimeMillis()}")
        if (expires.isNotBlank()) sb.appendLine("expires=$expires")
        if (noReshare) sb.appendLine("no_reshare=1")
        return sb.toString()
    }

    /** Single-line share link in the scheme matching the protocol (WireGuard: full config block). */
    fun toShareLink(): String {
        fun q(vararg keys: Pair<String, String>): String = keys
            .mapNotNull { (k, name) -> params[k]?.takeIf { it.isNotBlank() }?.let { "$name=${urlEncode(it)}" } }
            .joinToString("&")
        val frag = "#" + urlEncode(remark)
        val stream = q(
            "network" to "type", "security" to "security", "sni" to "sni", "alpn" to "alpn", "fp" to "fp",
            "allowInsecure" to "allowInsecure", "pbk" to "pbk", "sid" to "sid", "flow" to "flow",
            "path" to "path", "requestHost" to "host", "serviceName" to "serviceName"
        )
        return when (protocol) {
            Protocol.VMESS -> {
                val obj = JSONObject().apply {
                    put("v", "2"); put("ps", remark); put("add", host); put("port", port)
                    put("id", params["uuid"] ?: ""); put("aid", params["alterId"] ?: "0")
                    put("net", params["network"] ?: "tcp"); put("type", "none")
                    put("host", params["requestHost"] ?: ""); put("path", params["path"] ?: "")
                    put("tls", if (params["security"] == "tls") "tls" else "")
                    put("sni", params["sni"] ?: ""); put("alpn", params["alpn"] ?: ""); put("fp", params["fp"] ?: "")
                }
                "vmess://" + android.util.Base64.encodeToString(obj.toString().toByteArray(), android.util.Base64.NO_WRAP)
            }
            Protocol.VLESS -> "vless://${params["uuid"] ?: ""}@$host:$port?encryption=none" +
                (if (stream.isNotEmpty()) "&$stream" else "") + frag
            Protocol.TROJAN -> "trojan://${urlEncode(params["password"] ?: "")}@$host:$port" +
                (if (stream.isNotEmpty()) "?$stream" else "") + frag
            Protocol.SHADOWSOCKS -> {
                val ui = android.util.Base64.encodeToString(
                    "${params["method"] ?: "aes-256-gcm"}:${params["password"] ?: ""}".toByteArray(),
                    android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE
                )
                "ss://$ui@$host:$port$frag"
            }
            Protocol.HYSTERIA2 -> "hysteria2://${urlEncode(params["password"] ?: "")}@$host:$port?" +
                q("sni" to "sni", "obfs" to "obfs", "obfsPassword" to "obfs-password", "allowInsecure" to "insecure") + frag
            Protocol.TUIC -> "tuic://${params["uuid"] ?: ""}:${urlEncode(params["password"] ?: "")}@$host:$port?" +
                q("sni" to "sni", "alpn" to "alpn", "congestion" to "congestion_control", "udpRelayMode" to "udp_relay_mode") + frag
            Protocol.SSH_TUNNEL -> "ssh://${urlEncode(username)}:${urlEncode(params["password"] ?: "")}@$host:$port$frag"
            Protocol.WIREGUARD -> toExportText()
        }
    }

    companion object {
        fun fromJson(json: JSONObject): Profile {
            val paramsJson = json.optJSONObject("params") ?: JSONObject()
            val params = mutableMapOf<String, String>()
            paramsJson.keys().forEach { k -> params[k] = paramsJson.getString(k) }
            return Profile(
                id = json.getString("id"),
                username = json.optString("username"),
                remark = json.optString("remark"),
                host = json.optString("host"),
                port = json.optInt("port", 443),
                protocol = Protocol.valueOf(json.optString("protocol", Protocol.VMESS.name)),
                params = params,
                locked = json.optBoolean("locked", false),
                lockedAtEpochMs = if (json.isNull("lockedAtEpochMs")) null else json.optLong("lockedAtEpochMs"),
                expires = json.optString("expires", ""),
                noReshare = json.optBoolean("noReshare", false),
                imported = json.optBoolean("imported", false),
                createdAtEpochMs = json.optLong("createdAtEpochMs", System.currentTimeMillis())
            )
        }
    }
}

/** Tiny helper so URL fragments are safely encoded. */
private fun urlEncode(value: String): String =
    java.net.URLEncoder.encode(value, "UTF-8")
