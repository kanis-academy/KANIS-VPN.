package com.kanis.vpn.vpn

import android.net.VpnService
import com.kanis.vpn.model.Profile

data class TrafficStats(val rxBytesPerSec: Long, val txBytesPerSec: Long)

/**
 * One implementation per tunnel backend. [KanisVpnService] hands itself to the engine so it can
 * open the TUN (VpnService.Builder) and protect sockets. Engines throw on failure; the service
 * turns exceptions into an error broadcast.
 */
interface VpnEngine {
    /** Blocks until the tunnel is up (or throws). Called from a worker thread. */
    fun start(profile: Profile, service: VpnService)
    fun stop()
    val isRunning: Boolean
}
