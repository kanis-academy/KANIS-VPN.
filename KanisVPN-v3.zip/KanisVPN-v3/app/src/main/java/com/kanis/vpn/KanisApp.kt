package com.kanis.vpn

import android.app.Application
import android.util.Log
import io.nekohasekai.libbox.Libbox
import java.io.File

class KanisApp : Application() {

    override fun onCreate() {
        super.onCreate()
        com.kanis.vpn.util.AppPrefs.applyTheme(this)
        try {
            val base = filesDir.absolutePath
            val work = File(getExternalFilesDir(null) ?: filesDir, "singbox").apply { mkdirs() }.absolutePath
            val temp = cacheDir.absolutePath
            setupLibbox(base, work, temp)
        } catch (e: Throwable) {
            Log.e("KanisApp", "libbox setup failed: ${e.message}")
        }
    }

    /** Libbox.setup(base, work, temp, isTVOS) on 1.10; setup(SetupOptions) on newer releases. */
    private fun setupLibbox(base: String, work: String, temp: String) {
        val m = Libbox::class.java.methods.filter { it.name == "setup" }
        m.firstOrNull { it.parameterTypes.size == 4 }?.let {
            it.invoke(null, base, work, temp, false); return
        }
        val one = m.firstOrNull { it.parameterTypes.size == 1 } ?: return
        val opts = one.parameterTypes[0].getDeclaredConstructor().newInstance()
        fun set(name: String, value: Any) {
            opts.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == 1 }?.invoke(opts, value)
        }
        set("setBasePath", base); set("setWorkingPath", work); set("setTempPath", temp)
        one.invoke(null, opts)
    }
}
