package com.kanis.vpn.ui

import android.content.Context
import android.text.InputType
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.kanis.vpn.R
import com.kanis.vpn.model.ParamSpecs
import com.kanis.vpn.model.Profile

/** Builds the protocol-specific form (UUID, password, SNI, Reality keys, WireGuard keys…) in code. */
object ParamsDialog {

    fun show(context: Context, profile: Profile, onSaved: (Profile) -> Unit) {
        val specs = ParamSpecs.forProtocol(profile.protocol)
        val dp = context.resources.displayMetrics.density
        val pad = (20 * dp).toInt()

        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val fields = LinkedHashMap<String, EditText>()
        specs.forEach { spec ->
            column.addView(TextView(context).apply {
                text = spec.label
                textSize = 12f
                setPadding(0, (10 * dp).toInt(), 0, 0)
            })
            val edit = EditText(context).apply {
                hint = spec.hint
                setText(profile.params[spec.key] ?: "")
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or
                    if (spec.secret) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_NORMAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            fields[spec.key] = edit
            column.addView(edit)
        }

        AlertDialog.Builder(context)
            .setTitle(context.getString(R.string.params_title, profile.protocol.displayName))
            .setView(ScrollView(context).apply { addView(column) })
            .setPositiveButton(R.string.btn_ok) { _, _ ->
                val map = profile.params.toMutableMap()
                fields.forEach { (k, v) ->
                    val value = v.text.toString().trim()
                    if (value.isEmpty()) map.remove(k) else map[k] = value
                }
                onSaved(profile.copy(params = map))
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }
}
