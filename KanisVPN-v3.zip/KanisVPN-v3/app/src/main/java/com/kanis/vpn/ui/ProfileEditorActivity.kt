package com.kanis.vpn.ui

import android.app.DatePickerDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.kanis.vpn.R
import com.kanis.vpn.databinding.ActivityEditorBinding
import com.kanis.vpn.model.Profile
import com.kanis.vpn.model.Protocol
import com.kanis.vpn.profile.ProfileRepository
import com.kanis.vpn.util.AppPrefs
import com.kanis.vpn.util.ConfigLinkParser
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * The profile screen: where a profile is typed in, imported, edited, locked and exported.
 * A locked profile is read-only for good. Export locks automatically before it shares.
 */
class ProfileEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROFILE_ID = "profile_id"
        const val EXTRA_CONNECT = "connect"

        /** Locks [p] for good and stores it. Shared by the editor and the profile list. */
        fun lockAndStore(repo: ProfileRepository, p: Profile): Profile {
            val locked = p.copy(locked = true, lockedAtEpochMs = p.lockedAtEpochMs ?: System.currentTimeMillis())
            val exists = repo.get(p.id) != null
            if (exists) {
                // upsert refuses to rewrite a locked profile; replace the stored (unlocked) one first.
                repo.delete(p.id)
            }
            repo.upsert(locked)
            return locked
        }

        fun shareProfile(context: Context, p: Profile) {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "KANIS VPN profile: ${p.remark}")
                putExtra(Intent.EXTRA_TEXT, p.toExportText())
            }
            context.startActivity(Intent.createChooser(shareIntent, context.getString(R.string.btn_export)))
        }
    }

    private lateinit var binding: ActivityEditorBinding
    private lateinit var repo: ProfileRepository
    private var working: Profile = Profile()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = ProfileRepository(this)

        binding.toolbar.setNavigationOnClickListener { finish() }

        val names = Protocol.entries.map { it.displayName }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerProtocol.adapter = adapter

        working = repo.get(intent.getStringExtra(EXTRA_PROFILE_ID)) ?: Profile()
        bind(working)

        binding.edtExpires.setOnClickListener { pickExpiry() }
        binding.btnClearExpiry.setOnClickListener { if (!working.locked) binding.edtExpires.setText("") }
        binding.btnParams.setOnClickListener {
            val p = collect()
            working = p
            ParamsDialog.show(this, p) { updated -> working = updated }
        }
        binding.btnSave.setOnClickListener { onSave() }
        binding.btnLock.setOnClickListener { onLock() }
        binding.btnExport.setOnClickListener { onExport() }
        binding.btnImportClipboard.setOnClickListener { onImportClipboard() }
    }

    // ---------- Field <-> Profile ----------

    private fun bind(p: Profile) {
        binding.edtUsername.setText(p.username)
        binding.edtRemark.setText(p.remark)
        binding.edtHost.setText(p.host)
        binding.edtPort.setText(p.port.toString())
        binding.spinnerProtocol.setSelection(Protocol.entries.indexOf(p.protocol).coerceAtLeast(0))
        binding.edtExpires.setText(p.expires)
        binding.switchNoReshare.isChecked = p.noReshare
        applyLockUi(p)
    }

    private fun collect(): Profile {
        val newProtocol = Protocol.fromDisplayName(binding.spinnerProtocol.selectedItem?.toString() ?: "")
        val keep = newProtocol == working.protocol
        return working.copy(
            params = if (keep) working.params else mutableMapOf(),
            username = binding.edtUsername.text.toString(),
            remark = binding.edtRemark.text.toString(),
            host = binding.edtHost.text.toString().trim(),
            port = binding.edtPort.text.toString().toIntOrNull() ?: 443,
            protocol = newProtocol,
            expires = binding.edtExpires.text.toString().trim(),
            noReshare = binding.switchNoReshare.isChecked
        )
    }

    private fun applyLockUi(p: Profile) {
        val editable = !p.locked
        listOf<View>(
            binding.edtUsername, binding.edtRemark, binding.edtHost, binding.edtPort,
            binding.spinnerProtocol, binding.edtExpires, binding.btnClearExpiry,
            binding.switchNoReshare, binding.btnParams, binding.btnSave, binding.btnLock
        ).forEach { it.isEnabled = editable }
        binding.btnExport.isEnabled = p.canExport()
        if (p.locked) {
            val whenText = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                .format(Date(p.lockedAtEpochMs ?: System.currentTimeMillis()))
            var msg = getString(R.string.lock_banner, whenText)
            if (p.imported && p.noReshare) msg += getString(R.string.lock_banner_noreshare)
            binding.txtLockBanner.text = msg
            binding.txtLockBanner.visibility = View.VISIBLE
        } else {
            binding.txtLockBanner.visibility = View.GONE
        }
    }

    private fun pickExpiry() {
        if (working.locked) return
        val cal = Calendar.getInstance()
        val current = binding.edtExpires.text.toString()
        runCatching {
            SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(current)?.let { cal.time = it }
        }
        DatePickerDialog(this, { _, y, m, d ->
            binding.edtExpires.setText(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d))
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).apply {
            datePicker.minDate = System.currentTimeMillis() - 1000
        }.show()
    }

    // ---------- Actions ----------

    private fun requireHost(p: Profile): Boolean {
        if (p.host.isBlank()) {
            Toast.makeText(this, "Enter a host first", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun onSave() {
        val p = collect()
        if (!requireHost(p)) return
        working = p
        repo.upsert(p)
        AppPrefs.setCurrentId(this, p.id)
        Toast.makeText(this, R.string.toast_saved, Toast.LENGTH_SHORT).show()
    }

    private fun onLock() {
        val p = collect()
        if (!requireHost(p)) return
        AlertDialog.Builder(this)
            .setTitle(R.string.lock_confirm_title)
            .setMessage(R.string.lock_confirm_msg)
            .setPositiveButton(R.string.lock_confirm_yes) { _, _ ->
                working = lockAndStore(repo, p)
                AppPrefs.setCurrentId(this, working.id)
                applyLockUi(working)
                Toast.makeText(this, R.string.toast_locked_now, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun onExport() {
        var p = if (working.locked) working else collect()
        if (!requireHost(p)) return
        if (!p.canExport()) {
            Toast.makeText(this, R.string.toast_reshare_blocked, Toast.LENGTH_SHORT).show()
            return
        }
        if (!p.locked) {
            p = lockAndStore(repo, p)
            working = p
            AppPrefs.setCurrentId(this, p.id)
            applyLockUi(p)
            Toast.makeText(this, R.string.toast_locked_exported, Toast.LENGTH_SHORT).show()
        }
        shareProfile(this, p)
    }

    private fun onImportClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip
        if (clip == null || clip.itemCount == 0) {
            Toast.makeText(this, R.string.toast_clipboard_empty, Toast.LENGTH_SHORT).show()
            return
        }
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val all = ConfigLinkParser.parseAll(text)
        val first = all.firstOrNull()
        if (first == null) {
            Toast.makeText(this, R.string.toast_clipboard_invalid, Toast.LENGTH_SHORT).show()
            return
        }
        all.forEach { repo.upsert(it) }
        AppPrefs.setCurrentId(this, first.id)
        Toast.makeText(
            this,
            if (all.size > 1) getString(R.string.toast_imported_many, all.size) else getString(R.string.toast_imported),
            Toast.LENGTH_SHORT
        ).show()
        // Back to the home screen, which connects right away.
        setResult(RESULT_OK, Intent().putExtra(EXTRA_CONNECT, true))
        finish()
    }
}
