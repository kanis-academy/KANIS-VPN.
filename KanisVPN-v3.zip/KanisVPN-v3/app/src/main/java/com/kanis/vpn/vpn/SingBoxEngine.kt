package com.kanis.vpn.vpn

import android.content.Context
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.kanis.vpn.model.Profile
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.PlatformInterface
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Proxy

/**
 * Runs VMess, VLESS/Reality, Trojan, Shadowsocks, Hysteria2, TUIC and SSH on the embedded
 * sing-box core (libbox.aar, built by the GitHub workflow). The TUN is opened with the service's
 * VpnService.Builder; the app itself is excluded from the VPN so the core's own sockets reach
 * the real network without a routing loop.
 *
 * libbox's PlatformInterface gains/loses methods between sing-box releases, so it is implemented
 * as a dynamic proxy: only the methods we care about are answered, every other one gets a safe
 * default (false / 0 / empty / null). This keeps the build independent of the exact libbox version.
 */
class SingBoxEngine(private val context: Context) : VpnEngine {

    private var box: BoxService? = null
    private var tun: ParcelFileDescriptor? = null
    @Volatile override var isRunning: Boolean = false
        private set

    override fun start(profile: Profile, service: VpnService) {
        val config = SingBoxConfig.build(profile)
        Libbox.checkConfig(config) // throws with a readable message on a bad profile

        val handler = InvocationHandler { proxy, method, args ->
            when (method.name) {
                "openTun" -> openTun(service)
                "usePlatformAutoDetectInterfaceControl" -> true
                "autoDetectInterfaceControl" -> { service.protect(args[0] as Int); null }
                "writeLog" -> { Log.d("sing-box", args?.getOrNull(0)?.toString() ?: ""); null }
                "useProcFS" -> android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q
                "findConnectionOwner", "uidByPackageName" -> -1
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.getOrNull(0)
                "toString" -> "KanisPlatform"
                else -> defaultFor(method.returnType)
            }
        }
        val platform = Proxy.newProxyInstance(
            PlatformInterface::class.java.classLoader,
            arrayOf<Class<*>>(PlatformInterface::class.java),
            handler
        ) as PlatformInterface

        val svc = Libbox.newService(config, platform)
        box = svc
        svc.start()
        isRunning = true
    }

    private fun openTun(service: VpnService): Int {
        val b = service.Builder()
            .setSession("KANIS VPN")
            .addAddress(SingBoxConfig.TUN_ADDRESS, SingBoxConfig.TUN_PREFIX)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(SingBoxConfig.TUN_DNS)
            .setMtu(SingBoxConfig.TUN_MTU)
        try { b.addDisallowedApplication(context.packageName) } catch (ex: Exception) {}
        val pfd = b.establish() ?: throw IllegalStateException("VPN permission revoked or TUN refused")
        tun = pfd
        return pfd.fd
    }

    private fun defaultFor(type: Class<*>): Any? = when (type) {
        Boolean::class.javaPrimitiveType -> false
        Int::class.javaPrimitiveType -> 0
        Long::class.javaPrimitiveType -> 0L
        Float::class.javaPrimitiveType -> 0f
        Double::class.javaPrimitiveType -> 0.0
        String::class.java -> ""
        else -> null // void, iterators, WIFIState...
    }

    override fun stop() {
        isRunning = false
        try { box?.close() } catch (e: Exception) { Log.w("sing-box", "close: ${e.message}") }
        box = null
        try { tun?.close() } catch (ex: Exception) {}
        tun = null
    }
}
