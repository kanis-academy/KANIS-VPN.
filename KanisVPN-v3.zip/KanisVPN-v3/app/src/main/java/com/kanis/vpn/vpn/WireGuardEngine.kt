package com.kanis.vpn.vpn

import android.content.Context
import com.kanis.vpn.model.Profile
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.Interface
import com.wireguard.config.Peer

/**
 * Real WireGuard support via the official com.wireguard.android:tunnel library.
 * This one builds and runs with no extra setup beyond the Gradle dependency.
 *
 * Note: WireGuard owns its own VpnService (com.wireguard.android.backend.GoBackend$VpnService,
 * declared in the manifest), so unlike the other engines it does not take the TUN fd from
 * KanisVpnService directly -- it is driven through [Backend.setState] instead.
 */
class WireGuardEngine(private val context: Context) : VpnEngine {

    private var backend: Backend? = null
    private var tunnel: Tunnel? = null
    override var isRunning: Boolean = false
        private set

    override fun start(profile: Profile, service: android.net.VpnService) {
        val goBackend = GoBackend(context)
        backend = goBackend

        val config = buildConfig(profile)
        val kanisTunnel = object : Tunnel {
            override fun getName(): String = profile.remark.ifBlank { "kanis" }
            override fun onStateChange(newState: Tunnel.State) {
                isRunning = newState == Tunnel.State.UP
            }
        }
        tunnel = kanisTunnel
        goBackend.setState(kanisTunnel, Tunnel.State.UP, config)
        isRunning = true
    }

    override fun stop() {
        val goBackend = backend ?: return
        val activeTunnel = tunnel ?: return
        goBackend.setState(activeTunnel, Tunnel.State.DOWN, null)
        isRunning = false
    }

    private fun buildConfig(profile: Profile): Config {
        val p = profile.params
        val iface = Interface.Builder()
            .parsePrivateKey(p["privateKey"] ?: "")
            .parseAddresses(listOf(p["address"] ?: "10.0.0.2/32"))
            .apply {
                p["dns"]?.takeIf { it.isNotBlank() }?.let { parseDnsServers(listOf(it)) }
            }
            .build()

        val peer = Peer.Builder()
            .parsePublicKey(p["publicKey"] ?: "")
            .apply {
                p["presharedKey"]?.takeIf { it.isNotBlank() }?.let { parsePreSharedKey(it) }
            }
            .parseEndpoint("${profile.host}:${profile.port}")
            .parseAllowedIPs(listOf(p["allowedIPs"]?.takeIf { it.isNotBlank() } ?: "0.0.0.0/0, ::/0"))
            .build()

        return Config.Builder()
            .setInterface(iface)
            .addPeer(peer)
            .build()
    }
}
