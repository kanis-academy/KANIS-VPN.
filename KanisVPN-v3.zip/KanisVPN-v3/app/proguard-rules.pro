# Keep WireGuard and sing-box (gomobile) JNI/reflection classes
-keep class com.wireguard.** { *; }
-keep class io.nekohasekai.libbox.** { *; }
-keep class go.** { *; }
-dontwarn kotlin.**
