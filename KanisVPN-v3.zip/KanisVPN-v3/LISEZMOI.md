# Compiler KanisVPN sur GitHub

1. Crée un dépôt vide sur GitHub (ex. `KanisVPN`), sans README.
2. Dans ce dossier :

```bash
git init
git add .
git commit -m "KanisVPN"
git branch -M main
git remote add origin https://github.com/TON_PSEUDO/KanisVPN.git
git push -u origin main
```

3. Onglet **Actions → Build KanisVPN APK** : la compilation démarre toute seule (10 à 15 min). Tu peux aussi cliquer **Run workflow**.
4. Télécharge l'artefact **KanisVPN-apk** en bas de la page de l'exécution (APK par processeur + APK universel).

Utilise `git push` (pas le glisser-déposer du site) pour que le dossier caché `.github` soit envoyé.
Si une étape est en rouge, envoie-moi les 30 dernières lignes de son journal.

## Ce qui est dans cette version

- Barre du haut : menu (trois barres), logo + nom, icône profil.
- Menu latéral : Accueil, Profil, Tous les profils, thème sombre (clair par défaut), ID de l'application.
- Écran Profil : saisie, import, protocole, date d'expiration, blocage du re-partage, SAVE / LOCK / EXPORT.
- LOCK est définitif : personne ne peut déverrouiller ni modifier, même toi. EXPORT verrouille automatiquement.
- Après la date d'expiration, la connexion est refusée.
- Aucun profil d'exemple n'est inclus : l'application démarre vide.
